package com.project.doctorappointment.database

import androidx.room.*
import androidx.room.OnConflictStrategy.REPLACE
import com.project.doctorappointment.domain.message.modelchat.Chats
import kotlinx.coroutines.flow.Flow

@Dao
interface DoctorDao {
    @Insert
    suspend fun insertMedical(medicalBill: MedicalBill)

    @Insert
    fun insertUser(doctor: Doctor): Long

    @Query("select * from user")
    fun getListUser(): Flow<List<Doctor>>

    @Query("select * from user WHERE job LIKE:job ")
    fun getListUserJob(job: String): Flow<List<Doctor>>

    @Query("select * from user WHERE name LIKE  '%' || :search || '%' OR technique LIKE  '%' || :search || '%'")
    fun searchListDoctor(search: String): Flow<List<Doctor>>

    @Query("select * from user WHERE id LIKE :userId")
    fun getUser(userId: Int): Flow<Doctor>

    @Query("select job from user WHERE id_user LIKE :userId")
    fun getJobUser(userId: String): Flow<String>

    @Query("UPDATE user SET name=:name, phone=:phone, location=:address, email =:email WHERE id LIKE :userId")
    fun updateUserInfo(
        userId: Int,
        name: String,
        phone: String,
        address: String,
        email: String
    ): Int

    @Query("select * from chatBot ORDER BY it_chat ")
    fun getListChatBot(): Flow<List<ChatBot>>

    @Insert
    suspend fun sendMessager(chatBot: ChatBot)

    @Insert
    suspend fun initBook(bookDoctor: BookDoctor)

    @Query("select * from bookdoctor where id_User=:idUser")
    fun getListBookWithUser(idUser: Int): Flow<List<BookDoctor>>

    @Query("select * from bookdoctor where id_Doctor=:idDoctor")
    fun getListBookWithDoctor(idDoctor: Int): Flow<List<BookDoctor>>

    @Query("update bookdoctor set status=:status where id_book=:idBook")
    fun updateStatusBook(idBook: Int, status: String): Int

    @Query(
        "update bookdoctor set date=:date, time=:time, description=:description, " +
            "examination_form=:examinationForm, payment=:payment, status =:status where id_book=:idBook"
    )
    fun updateBook(
        idBook: Int,
        date: String,
        time: String,
        description: String,
        examinationForm: String,
        payment: String,
        status: String
    ): Int

    @Query("update user set ratePoint=:ratePoint, comment=:comment where id=:idDoctor")
    fun updateRate(idDoctor: Int, ratePoint: String, comment: String): Int

//    @Update
//    fun updateBook(bookDoctor: BookDoctor): Int

    @Delete
    fun deleteBook(bookDoctor: BookDoctor)

    @Insert
    suspend fun initChat(chats: Chats)

    @Query("DELETE FROM chatMessage")
    suspend fun deleteAll()

    //
//    @Update
//    fun updateUser(doctor: Doctor?)
//
//    @Delete
//    fun deleteUser(doctor: Doctor)
//
//    @Query("SELECT * FROM user ORDER BY id_user DESC")
//    fun getAllUsers(): LiveData<List<Doctor>>
//
    @Query("SELECT * FROM user WHERE phone LIKE :phone AND pass LIKE :password")
    fun getUser(phone: String?, password: String?): Doctor?

    @Query("SELECT * FROM user WHERE phone LIKE :phone")
    fun checkAccountWithPhoneNumber(phone: String?): Doctor?

    @Update(entity = Doctor::class, onConflict = REPLACE)
    suspend fun updatePassword(doctor: Doctor): Int

//    @Query("select * from User WHERE phone = :phone AND pass LIKE :password")
//    fun checkPhoneUser(phone: String?, password: String?): LiveData<List<Doctor>>
//
//    @Update
//    fun updateMedicalBill(medicalBill: MedicalBill)
//
//    @Delete
//    fun deleteMedicalBill(medicalBill: MedicalBill)
//
//    @Query("SELECT * FROM medical_bills ORDER BY id_patient DESC")
//    fun getAllMedicalBill(): LiveData<List<MedicalBill>>
//
//    @Query("SELECT * FROM user WHERE phone LIKE :phone AND pass LIKE :password")
//    suspend fun getMedicalBill(phone: String?, password: String?): MedicalBill?
//
//    @Query("select * from User WHERE phone = :phone AND pass LIKE :password")
//    fun checkPhoneMedicalBill(phone: String?, password: String?): LiveData<List<MedicalBill>>
}
