package com.project.doctorappointment.domain.login

import android.os.Bundle
import android.text.method.PasswordTransformationMethod
import android.util.Log
import android.view.View
import android.widget.Toast
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseAuth
import com.project.doctorappointment.R
import com.project.doctorappointment.base.BaseFragment
import com.project.doctorappointment.databinding.FragmentLoginScreenBinding
import com.project.doctorappointment.utils.ArgumentKey
import com.project.doctorappointment.utils.Const

class LoginFragment : BaseFragment<FragmentLoginScreenBinding, LoginViewModel>(), LoginListener {

    var email: String? = null
    var password: String? = null
    var mAuth: FirebaseAuth? = null
    override val viewModel: LoginViewModel by lazy { LoginViewModel(requireContext()) }
    override val layoutId: Int = R.layout.fragment_login_screen
    private var isShowPassword = false

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        arguments?.getString(ArgumentKey.USER_PHONE_KEY)?.let {
            viewModel.setPhone(it)
            Log.d(TAG, "onViewCreated: ")
        }
        arguments?.getString(ArgumentKey.USER_PASSWORD_KEY)?.let {
            viewModel.setPassword(it)
        }
        viewBinding.apply {
            onclick = this@LoginFragment
            viewModel = this@LoginFragment.viewModel
            mAuth = FirebaseAuth.getInstance()
        }
        observeResultLogin()
        rememberUser()
    }

    override fun onclickback() {
        addframent(R.id.welcome)
    }

    override fun onclicklogin() {
        viewBinding.apply {
            if (edtSdtPatient.text.toString().isEmpty()) {
                edtSdtPatient.error = getString(Const.INPUT_PHONE_ERROR)
                edtSdtPatient.requestFocus()
                return
            }
            if (edtSdtPatient.text.toString().length != 10) {
                edtSdtPatient.error = getString(Const.INPUT_PHONE_LENGTH_ERROR)
                edtSdtPatient.requestFocus()
                return
            }
            if (edtPassPatient.text.toString().isEmpty()) {
                edtPassPatient.error = getString(Const.INPUT_PASSWORD_ERROR)
                edtPassPatient.requestFocus()
                return
            }
            if (edtPassPatient.text.toString().length <= 7) {
                edtPassPatient.error = getString(Const.INPUT_PASSWORD_LENGTH_ERROR)
                edtPassPatient.requestFocus()
                return
            }
        }
        viewBinding.progressBar.visibility = View.VISIBLE
        viewModel.loginSuccess()
    }

    private fun observeResultLogin() {
        viewModel.isLoginSuccess.observe(viewLifecycleOwner) {
            viewBinding.progressBar.visibility = View.GONE
            when (it) {
                LoginViewModel.LOGIN_SUCCESS -> {
                    addframent(R.id.homePageScreen2)
                    viewBinding.apply {
                        LoginMeIn(edtSdtPatient.text.toString(), edtPassPatient.text.toString())
                    }
                    Toast.makeText(
                        requireContext(),
                        getString(Const.TOAST_LOGIN_SUCCESS),
                        Toast.LENGTH_SHORT
                    ).show()
                }
                LoginViewModel.LOGIN_FAILED -> {
                    Toast.makeText(
                        requireContext(),
                        getString(Const.TOAST_LOGIN_FAILED),
                        Toast.LENGTH_SHORT
                    ).show()
                }
                LoginViewModel.NOT_YET_REGISTER -> {
                    Toast.makeText(
                        requireContext(),
                        getString(Const.TOAST_NOT_YET_REGISTER),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    //
    private fun rememberUser() {
        Log.d(TAG, "rememberUser: called")
        viewBinding.cbRemember.setOnClickListener {
            viewModel.setIsRememberUser(viewBinding.cbRemember.isChecked)
        }
    }

    override fun onclickregister() {
        addframent(R.id.signupscreen)
    }

    override fun onClickForgotPassword() {
        Log.d(TAG, "onClickForgotPassword: ")
        addframent(R.id.forgotPasswordFragment)
    }

    override fun clickDrawbleEndPass() {
        viewBinding.edtPassPatient.apply {
            if (isShowPassword) {
                Log.d(TAG, "clickDrawbleEndPass: 1")
                transformationMethod = null
            } else {
                Log.d(TAG, "clickDrawbleEndPass: 2")
                transformationMethod = PasswordTransformationMethod()
            }
            isShowPassword = !isShowPassword
        }
    }

    private fun LoginMeIn(email: String, password: String) {
        mAuth?.signInWithEmailAndPassword(email, password)
            ?.addOnCompleteListener(
                OnCompleteListener<AuthResult?> { task ->
                    if (task.isSuccessful) {
                    }
                }
            )
    }
}