package com.project.doctorappointment.domain.chatbot

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.project.doctorappointment.database.ChatBot
import com.project.doctorappointment.databinding.ItemChatBotBinding

class ChatBotAdapter(var list: MutableList<ChatBot>) :
    RecyclerView.Adapter<ChatBotAdapter.ViewHolder>() {
    fun setData(list: ArrayList<ChatBot>) {
        this.list = list
        this.notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChatBotAdapter.ViewHolder {
        return ViewHolder(
            ItemChatBotBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: ChatBotAdapter.ViewHolder, position: Int) {
        holder.initData(chatBot = list[position], position)
    }

    override fun getItemCount(): Int = if (list != null) list.size else 0

    inner class ViewHolder(val binding: ItemChatBotBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun initData(chatBot: ChatBot, position: Int) {
            binding.apply {
                if (chatBot.type.equals("bot")) {
                    textBot = chatBot.message
                    check = true
                } else {
                    textUser = chatBot.message
                    check = false
                }
            }
        }
    }
}
