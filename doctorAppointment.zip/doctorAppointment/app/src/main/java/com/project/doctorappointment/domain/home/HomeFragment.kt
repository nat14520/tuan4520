package com.project.doctorappointment.domain.home

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.core.os.bundleOf
import androidx.recyclerview.widget.GridLayoutManager
import com.project.doctorappointment.R
import com.project.doctorappointment.base.BaseFragment
import com.project.doctorappointment.database.Doctor
import com.project.doctorappointment.databinding.FragmentHomeBinding
import java.util.ArrayList

class HomeFragment : BaseFragment<FragmentHomeBinding, HomeViewModel>(), HomeListener, HomeAdapter.McallBack {
    override val viewModel by lazy { HomeViewModel(application = requireContext()) }
    override val layoutId: Int = R.layout.fragment_home
    private val adapterHome by lazy {
        HomeAdapter(arrayListOf(), this)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewBinding.apply {
            title = "Home"
            onclick = this@HomeFragment
            grid = GridLayoutManager(requireContext(), 4)
            viewModel.apply {
                data.observe(viewLifecycleOwner) {
                    adapterHome.setData(it as ArrayList<Doctor>)
                    adapter = adapterHome
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.getListUser()
    }

    override fun onClick(doctor: Doctor) {
        addframent(R.id.openInfoDoctor, bundleOf("doctor" to doctor))
    }

    override fun onclickChatBot() {
        addframent(R.id.openChatBot)
    }

    override fun onClickSearchDoctor() {
        Log.d(TAG, "onClickSearchDoctor: ")
        addframent(R.id.searchDoctor)
    }
}
