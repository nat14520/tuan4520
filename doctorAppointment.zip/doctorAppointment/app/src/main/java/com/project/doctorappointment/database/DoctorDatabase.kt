package com.project.doctorappointment.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.project.doctorappointment.domain.message.modelchat.Chats

@Database(entities = [Doctor::class, MedicalBill::class, ChatBot::class, BookDoctor::class, Chats::class], version = 6)
abstract class DoctorDatabase : RoomDatabase() {
    abstract fun doctorDao(): DoctorDao

    companion object {
        @Volatile
        private var INTANCE: DoctorDatabase? = null
        fun getDatabase(context: Context): DoctorDatabase {
            val tempInstant = INTANCE
            if (tempInstant != null) {
                return tempInstant
            }
            synchronized(this) {
                val instant = Room.databaseBuilder(
                    context.applicationContext,
                    DoctorDatabase::class.java,
                    "database.db"
                ).allowMainThreadQueries().fallbackToDestructiveMigration().build()
                INTANCE = instant
                return instant
            }
        }
    }
}
