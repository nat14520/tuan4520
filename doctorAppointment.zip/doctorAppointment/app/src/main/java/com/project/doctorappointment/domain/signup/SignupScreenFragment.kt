package com.project.doctorappointment.domain.signup

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import com.project.doctorappointment.R
import com.project.doctorappointment.base.BaseFragment
import com.project.doctorappointment.databinding.FragmentSignUpScreenBinding
import com.project.doctorappointment.utils.Const
import com.project.doctorappointment.utils.TypeUser

class SignupScreenFragment : BaseFragment<FragmentSignUpScreenBinding, SignupScreenViewModel>(),
    SignupScreenListener {
    override val viewModel by lazy { SignupScreenViewModel(requireContext()) }
    override val layoutId: Int = R.layout.fragment_sign_up_screen

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewBinding.apply {
            onclick = this@SignupScreenFragment

        }
    }

    override fun onclickback() {
        addframent(R.id.welcome)
    }

    override fun onclickdoctor() {
        addframent(R.id.signupdoctor, bundleOf(Const.KEY_ID_JOB to TypeUser.TYPE_DOCTOR))
    }

    override fun onclickpatient() {
        addframent(R.id.signupdoctor, bundleOf(Const.KEY_ID_JOB to TypeUser.TYPE_PATIENT))
    }

    override fun onclicklogin() {
        addframent(R.id.login)
    }
}