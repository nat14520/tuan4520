package com.project.doctorappointment.domain.profileDoctor

import android.app.DatePickerDialog
import android.app.DatePickerDialog.OnDateSetListener
import android.app.TimePickerDialog
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.core.view.isVisible
import com.project.doctorappointment.R
import com.project.doctorappointment.base.BaseFragment
import com.project.doctorappointment.database.BookDoctor
import com.project.doctorappointment.database.Doctor
import com.project.doctorappointment.databinding.FragmentInfoDoctorBinding
import com.project.doctorappointment.utils.StatusType
import java.text.SimpleDateFormat
import java.util.*

class InfoDoctorFrament : BaseFragment<FragmentInfoDoctorBinding, InFoViewModel>(), InfoListener {
    override val viewModel by lazy { InFoViewModel(context = requireContext()) }
    override val layoutId: Int = R.layout.fragment_info_doctor
    private var user: Doctor? = null
    private val doctor by lazy {
        arguments?.getSerializable("doctor")
    }
    private val myCalendar = Calendar.getInstance()
    private var form: String? = null
    private var payment: String? = null
    private var isDoctor: Boolean = false
    private var isClickedButton = false

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewBinding.apply {
            if (doctor != null) {
                users = doctor as? Doctor
                ratePoint = users?.rate_point ?: "0"
            }
            viewModel.userDataLocal.observe(viewLifecycleOwner) {
                user = it.second
                isDoctor = it.second.job.equals("Doctor")
                listen = this@InfoDoctorFrament
                initView()
            }
            initListener()
        }
    }

    private fun initView() {
        viewBinding.apply {
            tvUnitLabel.isVisible = !isDoctor
            tvUnit.isVisible = !isDoctor
        }
    }

    private fun initListener() {
        viewBinding.apply {
            context?.let { ct ->
                rgForm.setOnCheckedChangeListener { radioGroup, checkedId ->
                    when (checkedId) {
                        rbOffline.id -> {
                            form = rbOffline.text.toString()
                            return@setOnCheckedChangeListener
                        }
                        rbOnline.id -> {
                            form = rbOnline.text.toString()
                            return@setOnCheckedChangeListener
                        }
                    }
                }

                rgPayment.setOnCheckedChangeListener { radioGroup, checkedId ->
                    when (checkedId) {
                        rbCash.id -> {
                            payment = rbCash.text.toString()
                            return@setOnCheckedChangeListener
                        }
                        rbTransfer.id -> {
                            payment = rbTransfer.text.toString()
                            return@setOnCheckedChangeListener
                        }
                    }
                }
            }
        }
    }

    private fun updateLabel() {
        val myFormat = "MM/dd/yy"
        val dateFormat = SimpleDateFormat(myFormat, Locale.US)
        viewBinding.date = dateFormat.format(myCalendar.time)
    }

    override fun onResume() {
        super.onResume()
        viewModel.getDataLocal()
        user?.idUser?.let { viewModel.getUser(it) }
    }

    override fun backStackHome() {
        backStack()
    }

    override fun onClickBookDoctor() {
        viewBinding.apply {
            if (!isDoctor) {
                viewModel.createInit(
                    BookDoctor(
                        name = (doctor as Doctor).name,
                        idDoctor = (doctor as Doctor).idUser,
                        idUser = user?.idUser,
                        date = edtBookDate.text.toString(),
                        time = edtBookHour.text.toString(),
                        description = edtDescription.text.toString(),
                        examinationForm = form,
                        payment = payment,
                        status = StatusType.DOI_XAC_NHAN.value
                    )
                )
                Toast.makeText(
                    requireContext(),
                    "Bạn đã đặt lịch thành công\n" +
                            "vui lòng đợi xác nhận",
                    Toast.LENGTH_SHORT
                ).show()
                backStack()
            }
        }
    }

    override fun onClickSelectDate() {
        val date =
            OnDateSetListener { view, year, month, day ->
                myCalendar.set(Calendar.YEAR, year)
                myCalendar.set(Calendar.MONTH, month)
                myCalendar.set(Calendar.DAY_OF_MONTH, day)
                updateLabel()
            }
        context?.let { ct ->
            DatePickerDialog(
                ct,
                date,
                myCalendar[Calendar.YEAR],
                myCalendar[Calendar.MONTH],
                myCalendar[Calendar.DAY_OF_MONTH]
            ).show()
        }
    }

    override fun onClickSelectTime() {
        val mCurrentTime = Calendar.getInstance()
        val hour = mCurrentTime[Calendar.HOUR_OF_DAY]
        val minute = mCurrentTime[Calendar.MINUTE]
        val mTimePicker: TimePickerDialog
        context?.let { ct ->
            mTimePicker = TimePickerDialog(
                ct,
                { timePicker, selectedHour, selectedMinute ->
                    viewBinding.time = "$selectedHour:$selectedMinute"
                },
                hour,
                minute,
                true
            )
            mTimePicker.setTitle("Select Time")
            mTimePicker.show()
        }
    }

    override fun onClickRate() {
        isClickedButton = true
        (doctor as? Doctor)?.let {
            DialogRateDoctor.newInstance(it){
                viewBinding.ratePoint = it
            }.show(
                parentFragmentManager,
                "confirmDialog"
            )
        }
    }

    override fun onClickMessage() {
        viewBinding.apply {
            val bundle = Bundle()
            bundle.putString("namedoctor", (doctor as Doctor).name.toString())
            bundle.putString("friendid", (doctor as Doctor).phone.toString())
            bundle.putString("userid", user?.phone.toString())
            addframent(R.id.chatMessageFragment, bundle)
        }
    }
}
