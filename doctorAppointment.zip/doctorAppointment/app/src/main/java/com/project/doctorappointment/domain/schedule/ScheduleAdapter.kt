package com.project.doctorappointment.domain.schedule

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.project.doctorappointment.R
import com.project.doctorappointment.database.BookDoctor
import com.project.doctorappointment.databinding.ItemSheduleBinding
import com.project.doctorappointment.utils.StatusType

class ScheduleAdapter(var list: MutableList<BookDoctor>, val mcallBack: McallBack) :
    RecyclerView.Adapter<ScheduleAdapter.ViewHolder>() {
    fun setData(list: ArrayList<BookDoctor>) {
        this.list = list
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ScheduleAdapter.ViewHolder {
        return ViewHolder(
            ItemSheduleBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: ScheduleAdapter.ViewHolder, position: Int) {
        holder.initData(mBook = list[position])
    }

    override fun getItemCount(): Int = list.size

    inner class ViewHolder(val binding: ItemSheduleBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun initData(mBook: BookDoctor) {
            binding.apply {
                book = mBook
                listener = mcallBack
                tvStatusValue.setTextColorStatus(mBook.status.toString())
            }
        }
    }

    private fun TextView.setTextColorStatus(status: String) {
        setTextColor(
            ContextCompat.getColor(
                this.context,
                when (status) {
                    StatusType.DA_TU_CHOI.value -> R.color.color_EB2121
                    StatusType.DOI_XAC_NHAN.value -> R.color.bluea8A7F9
                    StatusType.DA_XAC_NHAN.value -> R.color.green
                    else -> R.color.black
                }
            )
        )
    }

    interface McallBack {
        fun onClick(doctor: BookDoctor)
    }
}
