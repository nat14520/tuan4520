package com.project.doctorappointment.forgotpassword

import android.content.Context
import android.util.Log
import androidx.lifecycle.*
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewmodel.CreationExtras
import com.project.doctorappointment.base.BaseViewModel
import com.project.doctorappointment.database.Doctor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ForgotPasswordViewModel(context: Context) : BaseViewModel(context),
    ViewModelProvider.Factory {

    var phoneNumber = ""
    var newPassword = ""
    var newRePassword = ""
    private val _isAccountAlready = MutableLiveData(false)
    val isAccountAlready: LiveData<Boolean> = _isAccountAlready

    private val _isUpdatePasswordSuccess = MutableLiveData(false)
    val isUpdatePasswordSuccess: LiveData<Boolean> = _isUpdatePasswordSuccess

    private var userData = Doctor()

    fun isAccountAlready() {
        if (phoneNumber.isNotEmpty()) {
            Log.d(TAG, "isAccountAlready: called with phone number = $phoneNumber")
            val account = doctorDao.checkAccountWithPhoneNumber(phoneNumber)
            Log.d(
                TAG,
                "isAccountAlready: called with phone number = $phoneNumber and account = $account"
            )
            if (account != null) {
                _isAccountAlready.postValue(true)
                userData = account
                Log.d(TAG, "isAccountAlready: true ")
            } else {
                _isAccountAlready.postValue(false)
            }
        } else {
            Log.d(TAG, "isAccountAlready: failed ")
        }
    }

    fun confirmPassword() {
        Log.d(TAG, "confirmPassword: ")
        viewModelScope.launch(Dispatchers.IO) {
            userData.pass = newPassword
            val resultUpdate = doctorDao.updatePassword(userData)
            Log.d(
                TAG,
                "confirmPassword: called with value userData = $userData and result = $resultUpdate"
            )
            if (resultUpdate >= 0) {
                _isUpdatePasswordSuccess.postValue(true)
                userDataStore.storeUser(userData)
            } else _isUpdatePasswordSuccess.postValue(false)
        }
    }

    companion object {
        fun provideFactory(context: Context): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                override fun <T : ViewModel> create(
                    modelClass: Class<T>,
                    extras: CreationExtras
                ): T {
                    return ForgotPasswordViewModel(context) as T
                }
            }
    }
}