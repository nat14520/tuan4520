package com.project.doctorappointment.domain.schedule


import android.os.Bundle
import android.view.View
import androidx.core.os.bundleOf
import com.project.doctorappointment.R
import com.project.doctorappointment.base.BaseFragment
import com.project.doctorappointment.database.BookDoctor
import com.project.doctorappointment.databinding.FramentSheduleBinding

class ScheduleFragment : BaseFragment<FramentSheduleBinding, ScheduleViewModel>(),
    ScheduleAdapter.McallBack {
    override val viewModel by lazy { ScheduleViewModel(context = requireContext()) }
    override val layoutId: Int = R.layout.frament_shedule
    private val adapterSchedule by lazy {
        ScheduleAdapter(arrayListOf(), this)
    }
    private var isDoctor: Boolean = false

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.getDataLocal()
        initObserve()
    }

    private fun initObserve() {
        viewModel.userDataLocal.observe(viewLifecycleOwner) {
            isDoctor = it.second.job.equals("Doctor")
            if (isDoctor) {
                viewModel.getListBookWithDoctor(it.second.idUser)
            } else {
                viewModel.getListBookWithUser(it.second.idUser)
            }
        }

        viewModel.mListBook.observe(viewLifecycleOwner) {
            adapterSchedule.setData(it as ArrayList<BookDoctor>)
            viewBinding.adapter = adapterSchedule
        }
    }

    override fun onClick(bookDoctor: BookDoctor) {
        addframent(R.id.scheduleDetailScreen, bundleOf("book_doctor" to bookDoctor))
    }


}