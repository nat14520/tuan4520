package com.project.doctorappointment.domain.profileDoctor

interface IDialogRateListener {
    fun onClickConfirm()
    fun onClickCancel()
    fun onClickRate()
}