package com.project.doctorappointment.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user")
data class Doctor(
    @ColumnInfo(name = "id_user") var id: String = "",
    @ColumnInfo(name = "name") var name: String? = null,
    @ColumnInfo(name = "status") val status: String? = null,
    @ColumnInfo(name = "job") var job: String? = null,
    @ColumnInfo(name = "user_name") var user_name: String? = null,
    @ColumnInfo(name = "birthday") var birthday: String? = null,
    @ColumnInfo(name = "avata") var avata_url: String? = null,
    @ColumnInfo(name = "phone") var phone: String? = null,
    @ColumnInfo(name = "email") var email: String? = null,
    @ColumnInfo(name = "pass") var pass: String? = null,
    @ColumnInfo(name = "location") var location: String? = null,
    @ColumnInfo(name = "technique") var technique: String? = null,
    @ColumnInfo(name = "gender") var gender: String? = null,
    @ColumnInfo(name = "ratePoint")
    var rate_point: String? = null,
    @ColumnInfo(name = "comment")
    var comment: String? = null,
    @ColumnInfo(name = "role")
    val role: String? = null,
) : java.io.Serializable {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    var idUser: Int = 0
}
