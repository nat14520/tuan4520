package com.project.doctorappointment.domain.search_doctor.adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.project.doctorappointment.R
import com.project.doctorappointment.database.Doctor
import com.project.doctorappointment.databinding.ItemDoctorBinding
import com.project.doctorappointment.utils.TypeUser

class SearchDoctorAdapter : RecyclerView.Adapter<SearchDoctorAdapter.ItemDoctorHolder>() {

    private val _listDoctor = mutableListOf<Doctor>()

    private var onItemCLickListener: ((doctor: Doctor, view: View) -> Unit)? = null

    fun setOnClickListener(listener: ((doctor: Doctor, view: View) -> Unit)) {
        onItemCLickListener = listener
    }

    fun setData(listDoctor: List<Doctor>?) {
        Log.d("TAG", "setData: $listDoctor")
        listDoctor?.let {
            _listDoctor.clear()
            _listDoctor.addAll(listDoctor)
        }
        notifyDataSetChanged()
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemDoctorHolder {
        return ItemDoctorHolder(
            ItemDoctorBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: ItemDoctorHolder, position: Int) {
        holder.bindData(_listDoctor[position])
    }

    override fun getItemCount(): Int = _listDoctor.size

    inner class ItemDoctorHolder(private val binding: ItemDoctorBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bindData(doctor: Doctor) {
            binding.userName = doctor.name
            if (doctor.job == TypeUser.DOCTOR_VALUE) binding.imgAvatarDoctor.setImageResource(R.drawable.doctor)
            else binding.imgAvatarDoctor.setImageResource(
                R.drawable.patient
            )
            binding.root.setOnClickListener {
                Log.d("TAG", "bindData: onClick with data = $doctor")
                onItemCLickListener?.invoke(doctor, it)
            }
        }
    }
}