package com.project.doctorappointment.base

import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.project.doctorappointment.database.Doctor
import com.project.doctorappointment.database.DoctorDao
import com.project.doctorappointment.database.DoctorDatabase
import com.project.doctorappointment.store.UserDataStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

open class BaseViewModel(application: Context) : ViewModel() {
    protected val TAG by lazy { this::class.java.toString() }
    val doctorDao: DoctorDao
    val userDataStore: UserDataStore
    private val _userDataLocal = MutableLiveData<Pair<Boolean, Doctor>>()
    val userDataLocal: LiveData<Pair<Boolean, Doctor>> = _userDataLocal

    init {
        val doctorDatabase: DoctorDatabase = DoctorDatabase.getDatabase(application)
        doctorDao = doctorDatabase.doctorDao()
        userDataStore = UserDataStore.getInstance(context = application)
    }


    fun getDataLocal() {
        viewModelScope.launch(Dispatchers.IO) {
            userDataStore.userDataSaved.combine(userDataStore.isRememberAccount) { userData, isRemember ->
                Log.d(
                    TAG,
                    "getDataLocal: combine with data = $userData and isRemember = $isRemember"
                )
                Pair(isRemember, userData)
            }.collectLatest {
                Log.d(TAG, "getDataLocal: with data = $it")
                it?.let {
                    _userDataLocal.postValue(it)
                }
            }
        }
    }
}