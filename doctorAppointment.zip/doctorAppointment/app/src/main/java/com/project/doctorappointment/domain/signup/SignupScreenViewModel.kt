package com.project.doctorappointment.domain.signup

import android.content.Context
import com.project.doctorappointment.base.BaseViewModel

class SignupScreenViewModel(application: Context) : BaseViewModel(application) {
}