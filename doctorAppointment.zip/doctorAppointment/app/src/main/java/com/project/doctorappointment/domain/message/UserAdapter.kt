package com.project.doctorappointment.domain.message

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.project.doctorappointment.R
import com.project.doctorappointment.database.Doctor
import com.project.doctorappointment.databinding.LayoutofusersBinding
import com.project.doctorappointment.domain.message.modelchat.Chats
import de.hdodenhof.circleimageview.CircleImageView

class UserAdapter(
    var uid: String = "",
    var context: Context? = null,
    var userlist: MutableList<Doctor>,
    var isChat: Boolean = false,
    val mcallBack: McallBack
) : RecyclerView.Adapter<UserAdapter.MyHolder>() {

    var thelastmessage: String? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserAdapter.MyHolder {
        return MyHolder(
            LayoutofusersBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: MyHolder, position: Int) {
        val user: Doctor = userlist!![position]
        holder.itemView.setOnClickListener {
            mcallBack.onClick(doctor = user)
        }
        holder.username.setText(user.name)
        if (user.avata_url.equals("default")) {
            holder.imageView.setImageResource(R.drawable.user)
        } else {
            Glide.with(context!!).load(user.avata_url).into(holder.imageView)
        }
        if (isChat) {
            if (user.status.equals("online")) {
                holder.image_on.visibility = View.VISIBLE
                holder.image_off.visibility = View.GONE
            } else {
                holder.image_on.visibility = View.GONE
                holder.image_off.visibility = View.VISIBLE
            }
        } else {
            holder.image_on.visibility = View.GONE
            holder.image_off.visibility = View.GONE
        }
        if (isChat) {
            LastMessage(user.phone.toString(), holder.last_msg, holder)
        } else {
            holder.last_msg.visibility = View.GONE
        }
    }

    override fun getItemCount(): Int {
        return userlist!!.size
    }

    inner class MyHolder(val binding: LayoutofusersBinding) :
        RecyclerView.ViewHolder(binding.root),
        View.OnClickListener {
        var username: TextView
        var last_msg: TextView
        var imageView: CircleImageView
        var image_on: CircleImageView
        var image_off: CircleImageView

        init {
            username = itemView.findViewById(R.id.username_userfrag)
            imageView = itemView.findViewById(R.id.image_user_userfrag)
            image_on = itemView.findViewById(R.id.image_online)
            image_off = itemView.findViewById(R.id.image_offline)
            last_msg = itemView.findViewById(R.id.lastMessage)
        }

        override fun onClick(p0: View?) {
        }
    }

    private fun LastMessage(friendid: String, last_msg: TextView, holder: MyHolder) {
        thelastmessage = "default"
        val reference = FirebaseDatabase.getInstance().getReference("Chats")
        reference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                for (ds in snapshot.children) {
                    val chats: Chats? = ds.getValue(Chats::class.java)
                    if (uid != "" && chats != null) {
                        if (chats.sender.equals(friendid) && chats.reciever.equals(uid) ||
                            chats.sender.equals(uid) && chats.reciever
                                .equals(friendid)
                        ) {
                            thelastmessage = chats.message
                        }
                    }
                }
                when (thelastmessage) {
                    "default" -> holder.itemView.visibility = View.GONE
                    "default" -> holder.itemView.layoutParams = RecyclerView.LayoutParams(0, 0)
                    else -> last_msg.text = thelastmessage
                }
                thelastmessage = "default"
            }

            override fun onCancelled(error: DatabaseError) {}
        })
    }

    interface McallBack {
        fun onClick(doctor: Doctor)
    }
}
