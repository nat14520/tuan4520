package com.project.doctorappointment.domain.profileDoctor

import android.content.Context
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.project.doctorappointment.base.BaseViewModel
import com.project.doctorappointment.database.BookDoctor
import com.project.doctorappointment.database.Doctor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class InFoViewModel(context: Context) : BaseViewModel(context) {
    val mIsSuccess = MutableLiveData<Boolean>()
    val userData = MutableLiveData<Doctor>()

    fun createInit(bookDoctor: BookDoctor) {
        viewModelScope.launch(Dispatchers.IO) {
            doctorDao.initBook(bookDoctor)
        }
    }

    fun updateRate(idDoctor: Int, ratePoint: String, comment: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val isSuccess = doctorDao.updateRate(idDoctor, ratePoint, comment)
            if (isSuccess >= 0) {
                mIsSuccess.postValue(true)
            } else mIsSuccess.postValue(false)
        }
    }

    fun getUser(userId: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            doctorDao.getUser(userId).collect {
                userData.postValue(it)
                userDataStore.storeUser(it)
            }
        }
    }
}