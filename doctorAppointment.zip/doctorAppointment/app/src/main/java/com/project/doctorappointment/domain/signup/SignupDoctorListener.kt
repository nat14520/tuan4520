package com.project.doctorappointment.domain.signup

interface SignupDoctorListener {
    fun onclickback()
    fun onclickregister()
    fun onclicklogin()

    fun clickDrawbleEndPass()

    fun clickDrawbleEndRePass()
}