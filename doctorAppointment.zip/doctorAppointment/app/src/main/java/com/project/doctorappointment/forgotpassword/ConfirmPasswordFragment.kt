package com.project.doctorappointment.forgotpassword

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.activityViewModels
import com.project.doctorappointment.R
import com.project.doctorappointment.base.BaseFragment
import com.project.doctorappointment.databinding.FragmentConfirmPasswordBinding
import com.project.doctorappointment.utils.Const

class ConfirmPasswordFragment :
    BaseFragment<FragmentConfirmPasswordBinding, ForgotPasswordViewModel>(),
    IForgotPasswordListener {
    override val viewModel: ForgotPasswordViewModel by activityViewModels {
        ForgotPasswordViewModel.provideFactory(requireContext())
    }
    override val layoutId: Int = R.layout.fragment_confirm_password

    private var isClickConfirm = false

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewBinding.apply {
            onListener = this@ConfirmPasswordFragment
            viewModel = this@ConfirmPasswordFragment.viewModel
        }
        observeIsUpdatePassword()
    }

    override fun cancelUpdatePassword() {
        Log.d(TAG, "cancelUpdatePassword: called")
        addframent(R.id.login)
    }

    override fun confirmPassword() {
        viewModel.apply {
            Log.d(
                TAG,
                "confirmPassword: newPassword = $newPassword and repassword = $newRePassword"
            )
            if (newPassword.isEmpty()) {
                viewBinding.apply {
                    edtNewPassword.error = getString(Const.INPUT_PASSWORD_ERROR)
                    edtNewPassword.requestFocus()
                }
                return
            }

            if (newPassword.length <= 7) {
                viewBinding.apply {
                    edtNewPassword.error = getString(Const.INPUT_PASSWORD_LENGTH_ERROR)
                    edtNewPassword.requestFocus()
                }
                return
            }
            if (newRePassword.isEmpty()) {
                viewBinding.apply {
                    edtNewRePassword.error = getString(Const.INPUT_RE_PASSWORD_ERROR)
                    edtNewRePassword.requestFocus()
                }
                return
            }
            if (newPassword != newRePassword) {
                viewBinding.apply {
                    edtNewRePassword.error = getString(Const.INPUT_RE_PASSWORD_NOT_VALID)
                    edtNewRePassword.requestFocus()
                }
                return
            }
            viewBinding.progressBar.visibility = View.VISIBLE
        }
        viewModel.confirmPassword()
        isClickConfirm = true
    }

    override fun moveToRegisterScreen() {
        Log.d(TAG, "moveToRegisterScreen: called")
        addframent(R.id.signupscreen)
    }

    private fun observeIsUpdatePassword() {
        viewModel.isUpdatePasswordSuccess.observe(viewLifecycleOwner) {
            viewBinding.progressBar.visibility = View.GONE
            Log.d(TAG, "observeIsUpdatePassword: $it")
            if (it) {
                Toast.makeText(
                    requireContext(),
                    Const.TOAST_RESET_PASSWORD_SUCCESS,
                    Toast.LENGTH_LONG
                ).show()
                addframent(R.id.login)
            } else if (isClickConfirm) {
                Toast.makeText(
                    requireContext(),
                    Const.TOAST_RESET_PASSWORD_FAILED,
                    Toast.LENGTH_LONG
                ).show()
                isClickConfirm = false
            }
        }
    }
}