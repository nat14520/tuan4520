package com.project.doctorappointment.domain.home

import android.content.Context
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.project.doctorappointment.base.BaseViewModel
import com.project.doctorappointment.database.Doctor
import com.project.doctorappointment.utils.TypeUser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.prefs.Preferences


class HomeViewModel(application: Context) : BaseViewModel(application = application) {

    fun insertData(doctor: Doctor) = viewModelScope.launch(Dispatchers.IO) {
        doctorDao.insertUser(doctor = doctor)
    }

    val data = MutableLiveData<List<Doctor>>()
    fun getListUser() {
        viewModelScope.launch(Dispatchers.IO) {
            doctorDao.getListUserJob(TypeUser.DOCTOR_VALUE).collect {
                data.postValue(it)
            }
        }
    }
}