package com.project.doctorappointment.domain.schedule


import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.core.view.isVisible
import com.project.doctorappointment.R
import com.project.doctorappointment.base.BaseFragment
import com.project.doctorappointment.database.BookDoctor
import com.project.doctorappointment.database.Doctor
import com.project.doctorappointment.databinding.FramentSheduleDetailBinding
import com.project.doctorappointment.utils.StatusType
import com.project.doctorappointment.utils.TypeUser

class ScheduleDetailFragment : BaseFragment<FramentSheduleDetailBinding, ScheduleViewModel>(),
    ScheuleListener {
    override val viewModel by lazy { ScheduleViewModel(context = requireContext()) }
    override val layoutId: Int = R.layout.frament_shedule_detail
    private var isDoctor: Boolean = false
    private var user = Doctor()
    private val mBookDoctor by lazy { arguments?.getSerializable("book_doctor") as? BookDoctor }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.getDataLocal()
        viewBinding.apply {
            bookDoctor = mBookDoctor
            listen = this@ScheduleDetailFragment
        }
        initObserve()
    }

    private fun initObserve() {
        viewModel.userDataLocal.observe(viewLifecycleOwner) {
            user = it.second
            isDoctor = user.job.equals(TypeUser.DOCTOR_VALUE)
            Log.d(TAG, "initObserve: $isDoctor")
            initView()
        }

        viewModel.mIsSuccess.observe(viewLifecycleOwner) { isSuccess ->
            if (isSuccess) {
                Toast.makeText(requireContext(), "Cập nhật thành công!", Toast.LENGTH_SHORT).show()
                backStack()
            } else {
                Toast.makeText(requireContext(), "Lỗi cập nhật!", Toast.LENGTH_SHORT).show()
            }
        }

        viewModel.namePatient.observe(viewLifecycleOwner) {
            if (isDoctor) {
                Log.d(TAG, "initObserve: observer with name = $it and is doctor = $isDoctor")
                viewBinding.tvNameCustomer.text = it
            }
        }
    }

    private fun initView() {
        viewBinding.apply {
            clHeaderDoctor.isVisible = !isDoctor
            clHeaderCustomer.isVisible = isDoctor

            if (isDoctor) {
                rightButton = "Từ chối"
                leftButton = "Chấp nhận"
                viewBinding.tvDoctor.text = "Bệnh nhân"
                bookDoctor?.idUser?.let {
                    Log.d(TAG, "initView: get name patient with id user = $it")
                    viewModel.getNamePatient(it)
                }
                Log.d(TAG, "initView: is doctor ")
            } else {
                rightButton = "Xóa"
                leftButton = "Cập nhật"
                viewBinding.tvCustomer.text = "Bác sĩ"
                name = mBookDoctor?.name ?: ""
                Log.d(TAG, "initView: is patient ")
            }
        }
    }

    override fun onClickLeftButton() {
        if (isDoctor) {
            mBookDoctor?.idBook?.let {
                viewModel.updateStatus(it, StatusType.DA_XAC_NHAN.value)
            }
        } else {
            viewBinding.apply {
                mBookDoctor?.idBook?.let {
                    viewModel.updateBook(
                        idBook = it,
                        date = edtNgayKham.text.toString(),
                        time = edtGioKham.text.toString(),
                        description = edtDescription.text.toString(),
                        examinationForm = edtHinhThucKham.text.toString(),
                        payment = edtPayment.text.toString()
                    )
                }
            }
        }
    }

    override fun onClickRightButton() {
        if (isDoctor) {
            mBookDoctor?.idBook?.let {
                viewModel.updateStatus(it, StatusType.DA_TU_CHOI.value)
            }
        } else {
            mBookDoctor?.let {
                viewModel.deleteBook(it)
                backStack()
            }
        }
    }

    override fun onBackButton() {
        backStack()
    }
}