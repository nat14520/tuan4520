package com.project.doctorappointment.store

import android.content.Context
import android.util.Log
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.project.doctorappointment.database.Doctor
import com.project.doctorappointment.utils.PrefencesKey
import kotlinx.coroutines.flow.map

class UserDataStore private constructor(private val context: Context) {
    protected val TAG by lazy { this::class.java.toString() }

    suspend fun storeUser(doctor: Doctor) {
        Log.d(TAG, "storeUser: called with account = $doctor ")
        context.dataStore.edit {
            it[USER_ID_KEY] = doctor.idUser
            it[USER_NAME_KEY] = doctor.name ?: ""
            it[USER_PHONE_KEY] = doctor.phone ?: ""
            it[USER_PASSWORD_KEY] = doctor.pass ?: ""
            it[USER_JOB_KEY] = doctor.job ?: ""
            it[USER_TECHNIQUE_DOCTOR_KEY] = doctor.technique ?: ""
            it[USER_GENDER_KEY] = doctor.gender ?: ""
            it[USER_BIRTHDAY_KEY] = doctor.birthday ?: ""
            it[USER_LOCATION_KEY] = doctor.location ?: ""
            it[USER_EMAIL_KEY] = doctor.email ?: ""
        }
    }

    suspend fun rememberAccount(isRemember: Boolean) {
        Log.d(TAG, "rememberAccount: with isRemember = $isRemember")
        context.dataStore.edit {
            it[REMEMBER_ACCOUNT_KEY] = isRemember
        }
    }

    //đăng xuất dùng hàm này nhé
    suspend fun logOutStoreUser() {
        Log.d(TAG, "deleteStoreUser: called with account = $ ")
        context.dataStore.edit {
            it.clear()
        }
    }

    val userDataSaved = context.dataStore.data.map {
        Doctor(
            name = it[USER_NAME_KEY],
            phone = it[USER_PHONE_KEY],
            pass = it[USER_PASSWORD_KEY],
            job = it[USER_JOB_KEY],
            technique = it[USER_TECHNIQUE_DOCTOR_KEY],
            gender = it[USER_GENDER_KEY],
            birthday = it[USER_BIRTHDAY_KEY],
            location = it[USER_LOCATION_KEY],
            email = it[USER_EMAIL_KEY]
        ).apply {
            idUser = it[USER_ID_KEY] ?: -1
        }
    }

    val isRememberAccount = context.dataStore.data.map {
        it[REMEMBER_ACCOUNT_KEY] ?: false
    }

    companion object {
        private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = PrefencesKey.NAME)
        val USER_NAME_KEY = stringPreferencesKey(PrefencesKey.KEY_USER_NAME)
        val USER_PHONE_KEY = stringPreferencesKey(PrefencesKey.KEY_USER_PHONE)
        val USER_ID_KEY = intPreferencesKey(PrefencesKey.KEY_USER_ID)
        val USER_PASSWORD_KEY = stringPreferencesKey(PrefencesKey.KEY_USER_PASSWORD)
        val USER_JOB_KEY = stringPreferencesKey(PrefencesKey.KEY_USER_JOB)
        val REMEMBER_ACCOUNT_KEY = booleanPreferencesKey(PrefencesKey.REMEMBER_ACCOUNT)
        val USER_TECHNIQUE_DOCTOR_KEY = stringPreferencesKey(PrefencesKey.KEY_USER_TECHNIQUE_DOCTOR)
        val USER_BIRTHDAY_KEY = stringPreferencesKey(PrefencesKey.KEY_USER_BIRTHDAY)
        val USER_GENDER_KEY = stringPreferencesKey(PrefencesKey.KEY_USER_GENDER)
        val USER_LOCATION_KEY = stringPreferencesKey(PrefencesKey.KEY_LOCATION)
        val USER_EMAIL_KEY = stringPreferencesKey(PrefencesKey.KEY_EMAIL)


        @JvmStatic
        fun getInstance(context: Context) = UserDataStore(context)
    }
}