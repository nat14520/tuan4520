package com.project.doctorappointment.domain.search_doctor

interface ISearchDoctorListener {

    fun onBackScreen()

    fun onDeleteAll()
}