package com.project.doctorappointment.forgotpassword

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelLazy
import androidx.lifecycle.ViewModelProvider
import com.project.doctorappointment.R
import com.project.doctorappointment.base.BaseFragment
import com.project.doctorappointment.databinding.FragmentForgotPasswordBinding
import com.project.doctorappointment.utils.Const

class ForgotPasswordFragment :
    BaseFragment<FragmentForgotPasswordBinding, ForgotPasswordViewModel>(),
    IForgotPasswordListener {

    override val viewModel: ForgotPasswordViewModel by activityViewModels {
        ForgotPasswordViewModel.provideFactory(requireContext())
    }
    override val layoutId: Int = R.layout.fragment_forgot_password
    private var isClickedConfirm = false

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewBinding.apply {
            onListener = this@ForgotPasswordFragment
            viewModel = this@ForgotPasswordFragment.viewModel
        }
        observeIsCheckAccount()
    }

    override fun cancelUpdatePassword() {
        Log.d(TAG, "cancelUpdatePassword: ")
        addframent(R.id.login)
    }

    override fun confirmPassword() {
        Log.d(TAG, "confirmPassword: ")
        viewModel.apply {
            if (phoneNumber.isEmpty()) {
                viewBinding.edtPasswordOld.apply {
                    error = getString(Const.INPUT_PHONE_ERROR)
                    requestFocus()
                }
                return
            }
            if (phoneNumber.length != 10) {
                viewBinding.edtPasswordOld.apply {
                    error = getString(Const.INPUT_PHONE_LENGTH_ERROR)
                    requestFocus()
                }
                return
            }
            viewBinding.progressBar.visibility = View.VISIBLE
            isAccountAlready()
            isClickedConfirm = true
        }
    }

    override fun moveToRegisterScreen() {
        Log.d(TAG, "moveToRegisterScreen: ")
        addframent(R.id.signupscreen)
    }

    private fun observeIsCheckAccount() {
        viewModel.isAccountAlready.observe(viewLifecycleOwner) {
            Log.d(TAG, "observeIsCheckAccount: $it")
            viewBinding.progressBar.visibility = View.GONE
            if (it) {
                addframent(R.id.comfirmPasswordFragment)
            } else if (isClickedConfirm) {
                Toast.makeText(requireContext(), Const.TOAST_NOT_ALREADY_ACCOUNT, Toast.LENGTH_LONG)
                    .show()
                isClickedConfirm = false
            }
        }
    }
}