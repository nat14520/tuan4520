package com.project.doctorappointment.domain.message.modelchat

data class Chatslist(var id: String? = null)
