package com.project.doctorappointment.utils

import com.project.doctorappointment.R

object Const {
    const val VALUE_STRING_DEFAULT = ""
    const val INPUT_NAME_ERROR = R.string.input_name_error
    const val INPUT_PHONE_ERROR = R.string.input_phone_error
    const val INPUT_EMAIL_ERROR = R.string.input_email_error
    const val INPUT_PHONE_LENGTH_ERROR = R.string.input_phone_length_error
    const val INPUT_ADDRESS_ERROR = R.string.input_address_error
    const val INPUT_BIRTHDAY_ERROR = R.string.input_birthday_error
    const val INPUT_GENDER_ERROR = R.string.input_gender_error
    const val INPUT_PASSWORD_ERROR = R.string.input_password_error
    const val INPUT_PASSWORD_LENGTH_ERROR = R.string.input_length_password_error
    const val INPUT_RE_PASSWORD_ERROR = R.string.input_re_password_error
    const val INPUT_RE_PASSWORD_NOT_VALID = R.string.input_re_password_not_valid
    const val NOT_CHECK_POLICY = R.string.not_check_policy
    const val TOAST_REGISTER_USER_SUCCESS = R.string.toast_add_user_success
    const val TOAST_LOGIN_SUCCESS = R.string.toast_login_success
    const val TOAST_LOGIN_FAILED = R.string.toast_login_failed
    const val TOAST_NOT_YET_REGISTER = R.string.toast_not_yet_register
    const val TOAST_OLD_PASSWORD_ERROR = R.string.toast_old_password_failed
    const val TOAST_NOT_ALREADY_ACCOUNT = R.string.toast_not_yet_register
    const val TOAST_RESET_PASSWORD_SUCCESS = R.string.toast_reset_password_success
    const val TOAST_RESET_PASSWORD_FAILED = R.string.toast_reset_password_failed
    const val TOAST_ACCOUNT_IS_READLY = R.string.toast_account_is_readly
    const val TOAST_PASSWORD_FAILED = R.string.toast_reset_password_failed
    const val TOAST_NOT_CHOOSE_TECHNICAL = R.string.toast_not_choose_technique
    const val KEY_ID_JOB = "id_job"
    const val TECHNIQUE_ARRAYS = R.array.technical_arrays
    const val GENDER_ARRAYS = R.array.gender_arrays
    const val TITLE_CHOOSE_GENDER = R.string.title_choose_gender
}

object PrefencesKey {
    const val NAME = "UserData"
    const val KEY_USER_NAME = "USER_NAME"
    const val KEY_USER_ID = "USER_ID"
    const val KEY_USER_PHONE = "USER_PHONE"
    const val KEY_USER_PASSWORD = "USER_PASSWORD"
    const val KEY_USER_JOB = "USER_JOB"
    const val KEY_USER_TECHNIQUE_DOCTOR = "USER_TECHNIQUE_DOCTOR"
    const val KEY_USER_BIRTHDAY = "USER_BIRTHDAY"
    const val KEY_USER_GENDER = "USER_GENDER"
    const val REMEMBER_ACCOUNT = "REMEMBER_ACCOUNT"
    const val KEY_LOCATION ="LOCATION_USER"
    const val KEY_EMAIL ="EMAIL_USER"
}

object TechniqueDoctor {
    const val DA_KHOA = "Đa Khoa"
    const val RANG_HAM_MAT = "Răng Hàm Mặt"
    const val THAN_KINH = "Thần Kinh"
    const val XUONG_KHOP = "Xương Khớp"
    const val DA_KHOA_KEY = 1
    const val RANG_HAM_MAT_KEY = 2
    const val THAN_KINH_KEY = 3
    const val XUONG_KHOP_KEY = 4
}

object ArgumentKey {
    const val USER_PHONE_KEY = "UserName"
    const val USER_PASSWORD_KEY = "UserPassword"
}