package com.project.doctorappointment.domain.message.modelchat

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chatMessage")
data class Chats(
    @ColumnInfo(name = "sender")
    var sender: String? = null,
    @ColumnInfo(name = "reciever")
    var reciever: String? = null,
    @ColumnInfo(name = "message")
    var message: String? = null,
    @ColumnInfo(name = "isseen")
    var isseen: Boolean = false
) {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id_chat")
    var id_chat: Int = 0
}
