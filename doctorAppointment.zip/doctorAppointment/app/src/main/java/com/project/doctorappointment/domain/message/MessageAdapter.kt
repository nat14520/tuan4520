package com.project.doctorappointment.domain.message

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.project.doctorappointment.R
import com.project.doctorappointment.database.Doctor
import com.project.doctorappointment.domain.message.modelchat.Chats
import de.hdodenhof.circleimageview.CircleImageView

class MessageAdapter(
    var uid: String = "",
    var context: Context? = null,
    var chatslist: ArrayList<Chats>,
    var imageURL: String? = null,
) : RecyclerView.Adapter<MessageAdapter.MyHolder>() {
    val MESSAGE_RIGHT = 0

    val MESSAGE_LEFT = 1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyHolder {
        if (viewType == MESSAGE_RIGHT) {

            val view: View =
                LayoutInflater.from(context).inflate(R.layout.chat_item_right, parent, false)
            return MyHolder(view)
        } else {

            val view = LayoutInflater.from(context).inflate(R.layout.chat_item_left, parent, false)
            return MyHolder(view)
        }
    }

    override fun onBindViewHolder(holder: MyHolder, position: Int) {
        val chats = chatslist[position]
        holder.messagetext.text = chats.message
        if (imageURL == ""|| imageURL.isNullOrEmpty()) {
            holder.imageView.setImageResource(R.drawable.user)
        } else {
            Glide.with(context!!).load(imageURL).into(holder.imageView)
        }
        if (position == chatslist.size - 1) {
            if (chats.isseen) {
                holder.seen.text = "seen"
            } else {
                holder.seen.text = "Delivered"
            }
        } else {
            holder.seen.visibility = View.GONE
        }
    }

    override fun getItemCount(): Int {
        return chatslist!!.size
    }

    class MyHolder(val view: View) :
        RecyclerView.ViewHolder(view),
        View.OnClickListener {
        val messagetext: TextView = view.findViewById(R.id.show_message)
        val imageView: CircleImageView = view.findViewById(R.id.chat_image)
        val seen: TextView = view.findViewById(R.id.text_Seen)
        override fun onClick(p0: View?) {
        }
    }

    interface McallBack {
        fun onClick(doctor: Doctor)
    }

    override fun getItemViewType(position: Int): Int {
        return if (chatslist[position].sender.equals(uid)) {
            MESSAGE_RIGHT
        } else {
            MESSAGE_LEFT
        }
    }
}
