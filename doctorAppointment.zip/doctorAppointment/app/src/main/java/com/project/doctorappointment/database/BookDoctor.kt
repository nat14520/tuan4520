package com.project.doctorappointment.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity
class BookDoctor(
    @ColumnInfo(name = "name")
    val name: String? = null,
    @ColumnInfo(name = "id_Doctor")
    val idDoctor: Int? = null,
    @ColumnInfo(name = "id_User")
    val idUser: Int? = null,
    @ColumnInfo(name = "date")
    val date: String? = null,
    @ColumnInfo(name = "time")
    val time: String? = null,
    @ColumnInfo(name = "description")
    val description: String? = null,
    @ColumnInfo(name = "examination_form")
    val examinationForm: String? = null,
    @ColumnInfo(name = "payment")
    val payment: String? = null,
    @ColumnInfo(name = "status")
    val status: String? = null,
):java.io.Serializable {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id_book")
    var idBook: Int = 0
}
