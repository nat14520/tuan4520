package com.project.doctorappointment.domain

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.project.doctorappointment.R
import com.project.doctorappointment.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private val viewModel: MainViewModel by lazy { MainViewModel(applicationContext) }
    private val navHostFragment by lazy {
        supportFragmentManager.findFragmentById(R.id.container_fragment) as NavHostFragment
    }
    private val navController by lazy { navHostFragment.navController }

    private val binding by lazy { ActivityMainBinding.inflate(layoutInflater) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        viewModel.apply { }
        navController.apply {
            this
        }
        initView()
//        fullScreens()
    }

    private fun initView() {
        binding.navBottom.apply {
            setupWithNavController(navController)
        }
        navController.addOnDestinationChangedListener { _, destination, _ ->
            Log.d(TAG, "initView: ${navController.backQueue} and navigation = $destination.label")
            when (destination.id) {
                R.id.homePageScreen2 -> {
                    binding.groupNavigation.visibility = View.VISIBLE
                }
                R.id.manageScreen2 -> {
                    Log.d(TAG, "initView: mangaerScreen2")
                    binding.groupNavigation.visibility = View.VISIBLE
                }
                R.id.messageScreen2 -> {

                    binding.groupNavigation.visibility = View.VISIBLE
                }
                R.id.contractScreen2 -> {
                    binding.groupNavigation.visibility = View.VISIBLE
                }
                R.id.infoDoctor -> {
                    binding.groupNavigation.visibility = View.GONE
                }
                R.id.chatMessageFragment -> {
                    binding.groupNavigation.visibility = View.GONE
                }

                R.id.login, R.id.signupscreen, R.id.changePasswordFragment, R.id.settingScreen, R.id.welcome, R.id.chatbot, R.id.searchDoctor -> {
                    binding.groupNavigation.visibility = View.GONE
                }
            }
        }
    }

    private fun fullScreens() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
        }
    }

    override fun onBackPressed() {
        val startMain = Intent(Intent.ACTION_MAIN)
        startMain.addCategory(Intent.CATEGORY_HOME)
        startActivity(startMain)
        finish()
        Log.d(TAG, "onBackPressed: ")
    }

    protected val TAG by lazy { this::class.java.toString() }
}