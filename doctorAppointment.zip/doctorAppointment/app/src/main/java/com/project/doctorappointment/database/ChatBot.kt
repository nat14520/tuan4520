package com.project.doctorappointment.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
@Entity(tableName = "chatBot")
data class ChatBot(
    @ColumnInfo(name = "type")
    val type: String? = "",
    @ColumnInfo(name = "message")
    val message: String? = ""
){
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "it_chat")
    var id: Int = 0
}
