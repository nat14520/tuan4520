package com.project.doctorappointment.domain.wellcome

import com.project.doctorappointment.database.Doctor

interface WellcomeListener {
    fun onclickRegister()
    fun onclickLogin()
    fun onClick(doctor: Doctor)
}