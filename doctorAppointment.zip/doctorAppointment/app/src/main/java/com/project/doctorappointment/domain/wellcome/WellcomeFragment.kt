package com.project.doctorappointment.domain.wellcome

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.core.os.bundleOf
import com.project.doctorappointment.R
import com.project.doctorappointment.base.BaseFragment
import com.project.doctorappointment.database.Doctor
import com.project.doctorappointment.databinding.FragmentWelcomeScreenBinding
import com.project.doctorappointment.domain.home.HomeViewModel


class WellcomeFragment : BaseFragment<FragmentWelcomeScreenBinding, WellcomeViewModel>(),
    WellcomeListener {
    override val viewModel by lazy { WellcomeViewModel(requireContext()) }
    override val layoutId: Int = R.layout.fragment_welcome_screen

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewBinding.apply {
            onclick = this@WellcomeFragment

        }
        viewModel.getDataLocal()
        observeUserSaved()
    }

    override fun onClick(doctor: Doctor) {
        Log.d("TAG", "onClick: ")

    }

    override fun onclickRegister() {
        Log.d(TAG, "onclickRegister: ")
        addframent(R.id.signupscreen)
    }

    override fun onclickLogin() {
        Log.d(TAG, "onclickLogin: ")
        addframent(R.id.login)
    }

    private fun observeUserSaved() {
        viewModel.userDataLocal.observe(viewLifecycleOwner) { data ->
            Log.d(TAG, "observeUserSaved: $data")
            if (data.first && data.second.idUser > -1 && !data.second.phone.isNullOrEmpty()) {
                Log.d(TAG, "observeUserSaved: calledd with true ")
                addframent(R.id.homePageScreen2)
            } else Log.d(TAG, "observeUserSaved: called with no remmeber")
        }
    }


}