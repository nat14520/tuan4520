package com.project.doctorappointment.domain.signup

interface SignupScreenListener {
    fun onclickback()
    fun onclickdoctor()
    fun onclickpatient()
    fun onclicklogin()
}