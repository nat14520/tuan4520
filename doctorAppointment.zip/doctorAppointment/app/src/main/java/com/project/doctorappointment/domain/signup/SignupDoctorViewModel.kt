package com.project.doctorappointment.domain.signup

import android.content.Context
import android.util.Log
import com.project.doctorappointment.base.BaseViewModel
import android.util.Patterns.PHONE
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.project.doctorappointment.database.Doctor
import com.project.doctorappointment.utils.Const

class SignupDoctorViewModel(application: Context) : BaseViewModel(application) {

    private val _isInsertUserSuccess = MutableLiveData(false)
    val isInsertUserSuccess: LiveData<Boolean> = _isInsertUserSuccess

    private var _userData = Doctor()
    val userData = _userData

    private val _isAccountAlready = MutableLiveData(false)
    val isAccountAlready: LiveData<Boolean> = _isAccountAlready

    fun insertUser(technicalDoctor: String) {
        Log.d(
            TAG,
            "insertUser: called with user = $_userData and techicalDoctor = $technicalDoctor"
        )
        doctorDao.checkAccountWithPhoneNumber(userData.phone)?.let {
            Log.d(TAG, "insertUser: user is already = $it")
            _isAccountAlready.postValue(true)
        } ?: insertUserToDatabase()
    }

    private fun insertUserToDatabase() {
        val result = doctorDao.insertUser(userData)
        if (result > -1)
            _isInsertUserSuccess.postValue(true)
    }

    fun setLocation(location: String) {
        Log.d(TAG, "setLocation: called with location = $location")
        userData.location = location
    }

    fun setJob(job: String) {
        Log.d(TAG, "setJob: called with job = $job")
        userData.job = job
    }

    fun setTechnicalDoctor(tech: String) {
        Log.d(TAG, "setTechnicalDoctor: $tech")
        userData.technique = tech
    }
}