package com.project.doctorappointment.domain.message

import android.content.Context
import com.project.doctorappointment.base.BaseViewModel

class ListMessageViewModel(context: Context):BaseViewModel(context) {
}