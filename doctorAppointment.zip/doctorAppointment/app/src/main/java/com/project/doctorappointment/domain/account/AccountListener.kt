package com.project.doctorappointment.domain.account

interface AccountListener {
    fun goToSetting()
}