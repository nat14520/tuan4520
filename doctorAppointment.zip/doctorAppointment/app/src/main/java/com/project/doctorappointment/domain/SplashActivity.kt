package com.project.doctorappointment.domain

import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.project.doctorappointment.databinding.ActivitySplashSceenBinding
import com.project.doctorappointment.domain.wellcome.WellcomeFragment
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SplashActivity : AppCompatActivity() {
    private val binding by lazy { ActivitySplashSceenBinding.inflate(layoutInflater) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
    }

    override fun onResume() {
        super.onResume()
        binding.apply {
            loadingSplash.max = 100
            loadingSplash.scaleY = 3f
            val objectAnimator: ObjectAnimator =
                ObjectAnimator.ofInt(loadingSplash, "progress", 0, 100)
            objectAnimator.duration = 3000
            objectAnimator.start()
            MainScope().launch {
                delay(3000)
                startActivity(Intent(this@SplashActivity, MainActivity::class.java))
            }
        }
    }
}

