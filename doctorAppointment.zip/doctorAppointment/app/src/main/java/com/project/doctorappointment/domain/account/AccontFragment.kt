package com.project.doctorappointment.domain.account


import android.os.Bundle
import android.view.View
import androidx.core.view.isVisible
import com.project.doctorappointment.R
import com.project.doctorappointment.base.BaseFragment
import com.project.doctorappointment.database.Doctor
import com.project.doctorappointment.databinding.FragmentAccountBinding
import com.project.doctorappointment.utils.TypeUser

class AccontFragment : BaseFragment<FragmentAccountBinding, AccountViewModel>(), AccountListener {
    override val viewModel by lazy { AccountViewModel(context = requireContext()) }
    override val layoutId: Int = R.layout.fragment_account
    private var isDoctor: Boolean = false
    private var user = Doctor()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.getDataLocal()
        initListener()
        initObserve()
    }

    private fun initObserve() {
        viewModel.userDataLocal.observe(viewLifecycleOwner) {
            user = it.second
            viewBinding.users = it.second
            isDoctor = user.job.equals("Doctor")
            if (it.second.job.equals(TypeUser.DOCTOR_VALUE)){
                viewBinding.imgAvatarDoctor.setImageResource(R.drawable.doctor)
            }
            viewModel.getUser(it.second.idUser)
        }
        viewModel.userData.observe(viewLifecycleOwner){ model ->
            initView(model)
        }
    }

    override fun goToSetting() {
        addframent(R.id.settingScreen)
    }

    private fun initListener() {
        viewBinding.apply {
            title = getString(R.string.profileLabel)
            listen = this@AccontFragment
        }
    }

    private fun initView(model: Doctor) {
        viewBinding.apply {
            ctlCustomerProfile.isVisible = !isDoctor
            tvAddress.isVisible = !isDoctor
            tvAddressLabel.isVisible = !isDoctor
            ctlDoctorProfile.isVisible = isDoctor
            llRate.isVisible = isDoctor
            imgLocation.isVisible = isDoctor
            tvLocation.isVisible = isDoctor
            tvUnit.isVisible = isDoctor
            tvUnitLabel.isVisible = isDoctor

            name = if (model.name?.isNotEmpty() == true) model.name else "null"
            location = if (model.location?.isNotEmpty() == true) model.location else "null"
            phone = if (model.phone?.isNotEmpty() == true) model.phone else "null"
            birthDate = if (model.birthday?.isNotEmpty() == true) model.birthday else "null"
            gender = if (model.gender?.isNotEmpty() == true) model.gender else "null"
            unit = if (model.technique?.isNotEmpty() == true) model.technique else "null"
            ratePoint = if (model.rate_point?.isNotEmpty() == true) model.rate_point else "0"
        }
    }
}