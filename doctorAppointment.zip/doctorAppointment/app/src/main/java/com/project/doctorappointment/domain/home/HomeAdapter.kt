package com.project.doctorappointment.domain.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.project.doctorappointment.database.Doctor
import com.project.doctorappointment.databinding.ItemHomeBinding

class HomeAdapter(var list: MutableList<Doctor>, val mcallBack: McallBack) :
    RecyclerView.Adapter<HomeAdapter.ViewHolder>() {
    fun setData(list: ArrayList<Doctor>) {
        this.list = list
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HomeAdapter.ViewHolder {
        return ViewHolder(
            ItemHomeBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: HomeAdapter.ViewHolder, position: Int) {
        holder.initData(doctor = list[position])
    }

    override fun getItemCount(): Int = if (list != null) list.size else 0

    inner class ViewHolder(val binding: ItemHomeBinding) : RecyclerView.ViewHolder(binding.root) {
        fun initData(doctor: Doctor) {
            binding.apply {
                user = doctor
                listener = mcallBack
            }
        }
    }

    interface McallBack {
        fun onClick(doctor: Doctor)
    }
}
