package com.project.doctorappointment.domain.wellcome

import android.content.Context
import com.project.doctorappointment.base.BaseViewModel

class WellcomeViewModel(application: Context) : BaseViewModel(application) {
}