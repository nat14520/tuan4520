package com.project.doctorappointment.forgotpassword

import android.os.Bundle
import android.text.method.PasswordTransformationMethod
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.fragment.app.activityViewModels
import com.project.doctorappointment.R
import com.project.doctorappointment.base.BaseFragment
import com.project.doctorappointment.databinding.FragmentChangePasswordBinding
import com.project.doctorappointment.utils.Const

class ChangePasswordFragment :
    BaseFragment<FragmentChangePasswordBinding, ChangePasswordViewModel>(),
    IChangePasswordListener {
    private var isShowOldPassword = false
    private var isShowEnterPassword = false
    private var isShowNewPassword = false
    override val viewModel: ChangePasswordViewModel by activityViewModels {
        ChangePasswordViewModel.provideFactory(requireContext())
    }
    override val layoutId: Int = R.layout.fragment_change_password
    private val dialogConfirm = DialogConfirmPassword()
    private var isClickedButton = false

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewBinding.apply {
            viewModel = this@ChangePasswordFragment.viewModel
            onListener = this@ChangePasswordFragment
        }
        observeResultChangePassword()
        observeDismissDialog()
        observeShowLoading()
    }

    override fun onBackScreen() {
        Log.d(TAG, "onBackScreen: ")
        backStack()
    }

    override fun onConfirmChangePassword() {
        viewModel.apply {
            Log.d(
                TAG,
                "confirmPassword: newPassword = $newPassword and repassword = $reNewPassword and oldPassword = $oldPassword"
            )
            if (oldPassword.isEmpty()) {
                viewBinding.apply {
                    edtOldPassword.error = getString(Const.INPUT_PASSWORD_ERROR)
                    edtOldPassword.requestFocus()
                }
                return
            }

            if (oldPassword.length <= 7) {
                viewBinding.apply {
                    edtOldPassword.error = getString(Const.INPUT_PASSWORD_LENGTH_ERROR)
                    edtOldPassword.requestFocus()
                }
                return
            }
            if (newPassword.isEmpty()) {
                viewBinding.apply {
                    edtNewPassword.error = getString(Const.INPUT_PASSWORD_ERROR)
                    edtNewPassword.requestFocus()
                }
                return
            }

            if (newPassword.length <= 7) {
                viewBinding.apply {
                    edtNewPassword.error = getString(Const.INPUT_PASSWORD_LENGTH_ERROR)
                    edtNewPassword.requestFocus()
                }
                return
            }
            if (reNewPassword.isEmpty()) {
                viewBinding.apply {
                    edtEnterThePassword.error = getString(Const.INPUT_RE_PASSWORD_ERROR)
                    edtEnterThePassword.requestFocus()
                }
                return
            }
            if (newPassword != reNewPassword) {
                viewBinding.apply {
                    edtEnterThePassword.error = getString(Const.INPUT_RE_PASSWORD_NOT_VALID)
                    edtEnterThePassword.requestFocus()
                }
                return
            }
            Log.d(
                TAG,
                "onConfirmChangePassword:oldPassword = $oldPassword && pass = ${userData.pass} "
            )
            if (oldPassword != userData.pass) {
                Toast.makeText(requireContext(), Const.TOAST_OLD_PASSWORD_ERROR, Toast.LENGTH_LONG)
                    .show()
                return
            }
        }
        isClickedButton = true
        showDialogConfirm()
    }

    override fun clickDrawbleEndNewPass() {
        viewBinding.edtNewPassword.apply {
            if (isShowNewPassword) {
                Log.d(TAG, "clickDrawbleEndPass: 1")
                transformationMethod = null
            } else {
                Log.d(TAG, "clickDrawbleEndPass: 2")
                transformationMethod = PasswordTransformationMethod()
            }
            isShowNewPassword = !isShowNewPassword
        }
    }

    override fun clickDrawbleEndOldPass() {
        viewBinding.edtOldPassword.apply {
            if (isShowOldPassword) {
                Log.d(TAG, "clickDrawbleEndPass: 1")
                transformationMethod = null
            } else {
                Log.d(TAG, "clickDrawbleEndPass: 2")
                transformationMethod = PasswordTransformationMethod()
            }
            isShowOldPassword = !isShowOldPassword
        }
    }

    override fun clickDrawbleEndEnterPass() {
        viewBinding.edtEnterThePassword.apply {
            if (isShowEnterPassword) {
                Log.d(TAG, "clickDrawbleEndPass: 1")
                transformationMethod = null
            } else {
                Log.d(TAG, "clickDrawbleEndPass: 2")
                transformationMethod = PasswordTransformationMethod()
            }
            isShowEnterPassword = !isShowEnterPassword
        }
    }

    private fun showDialogConfirm() {
        Log.d(TAG, "showDialogConfirm: ")
        dialogConfirm.show(parentFragmentManager, "confirmDialog")
    }

    private fun observeResultChangePassword() {
        viewModel.isChangePasswordSuccess.observe(viewLifecycleOwner) {
            Log.d(TAG, "observeResultChangePassword: called with $it")
            if (it && isClickedButton) {
                dialogConfirm.dismiss()
                Toast.makeText(
                    requireContext(),
                    Const.TOAST_RESET_PASSWORD_SUCCESS,
                    Toast.LENGTH_LONG
                ).show()
                isClickedButton = false
                backStack()
                viewModel.saveDataStore()
            } else if (isClickedButton) {
                dialogConfirm.dismiss()
                Toast.makeText(
                    requireContext(),
                    Const.TOAST_RESET_PASSWORD_FAILED,
                    Toast.LENGTH_LONG
                ).show()
                isClickedButton = false
            }
        }
    }

    private fun observeDismissDialog() {
        Log.d(TAG, "observeDismissDialog: ")
        viewModel.isDismisDialog.observe(viewLifecycleOwner) {
            Log.d(TAG, "observeDismissDialog: $it")
            if (it && isClickedButton) {
                dialogConfirm.dismiss()
            }
        }
    }

    private fun observeShowLoading() {
        Log.d(TAG, "observeShowLoading: ")
        viewModel.isShowLoading.observe(viewLifecycleOwner) {
            Log.d(TAG, "observeShowLoading: $it")
            if (it) viewBinding.progressBar.visibility =
                View.VISIBLE else viewBinding.progressBar.visibility = View.GONE
        }
    }

}