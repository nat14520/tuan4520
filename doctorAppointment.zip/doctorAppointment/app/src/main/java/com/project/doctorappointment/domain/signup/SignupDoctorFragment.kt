package com.project.doctorappointment.domain.signup

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.DatePickerDialog.OnDateSetListener
import android.os.Bundle
import android.text.method.PasswordTransformationMethod
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.core.view.isVisible
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.project.doctorappointment.R
import com.project.doctorappointment.base.BaseFragment
import com.project.doctorappointment.database.Doctor
import com.project.doctorappointment.databinding.FragmentSignUpDoctorBinding
import com.project.doctorappointment.utils.ArgumentKey
import com.project.doctorappointment.utils.Const
import com.project.doctorappointment.utils.TechniqueDoctor
import com.project.doctorappointment.utils.TypeUser
import java.text.SimpleDateFormat
import java.util.*

class SignupDoctorFragment() :
    BaseFragment<FragmentSignUpDoctorBinding, SignupDoctorViewModel>(),
    SignupDoctorListener {
    private var mAuth: FirebaseAuth? = null
    private var reference: DatabaseReference? = null
    override val viewModel by lazy { SignupDoctorViewModel(requireContext()) }
    override val layoutId: Int = R.layout.fragment_sign_up_doctor
    var location: String? = null
    var jobInsert: String? = null
    private var techniqueDoctor: String = ""
    private val myCalendar = Calendar.getInstance()
    private var isShowPassword = false
    private var isShowRePassword = false

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewBinding.apply {
            mAuth = FirebaseAuth.getInstance()

            onclick = this@SignupDoctorFragment
            viewModel = this@SignupDoctorFragment.viewModel
        }
        initViewChooseTechnical()
        Log.d(TAG, "onViewCreated: ${arguments?.getInt(Const.KEY_ID_JOB)}")
        if (arguments?.getInt(Const.KEY_ID_JOB) == TypeUser.TYPE_DOCTOR) {
            viewModel.setJob(TypeUser.DOCTOR_VALUE)
            jobInsert = TypeUser.DOCTOR_VALUE
            viewBinding.edtLocationDoctor.visibility = View.VISIBLE
            viewBinding.technique.visibility = View.VISIBLE
        } else {
            viewBinding.edtLocationDoctor.visibility = View.GONE
            viewModel.setLocation(Const.VALUE_STRING_DEFAULT)
            jobInsert = TypeUser.PATIENT_VALUE
            viewBinding.technique.visibility = View.GONE
            viewModel.setJob(TypeUser.PATIENT_VALUE)
            viewBinding.edtLocationDoctor.visibility = View.VISIBLE
        }
        showDialogChooseBirthday()
        showDialogChooseGender()
        showToastAccountIsAlready()
        observeResultInsertSuccess()
    }

    private fun observeResultInsertSuccess() {
        viewModel.isInsertUserSuccess.observe(viewLifecycleOwner) {
            viewBinding.progressBar.visibility = View.GONE
            if (it) {
                Log.d(
                    TAG,
                    "onViewCreated: username = ${viewModel.userData.name} && password = ${viewModel.userData.pass}"
                )
                viewBinding.apply {
                    registerUser(
                        username = edtNameDoctor.text.toString(),
                        password = edtPassDoctor.text.toString(),
                        phone = edtSdtDoctor.text.toString()
                    )
                }

                addframent(
                    R.id.login,
                    bundleOf(
                        ArgumentKey.USER_PHONE_KEY to viewModel.userData.phone,
                        ArgumentKey.USER_PASSWORD_KEY to viewModel.userData.pass
                    )
                )
                Toast.makeText(
                    requireContext(),
                    getString(Const.TOAST_REGISTER_USER_SUCCESS),
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun showToastAccountIsAlready() {
        viewModel.isAccountAlready.observe(viewLifecycleOwner) {
            if (it) {
                Toast.makeText(
                    context,
                    Const.TOAST_ACCOUNT_IS_READLY,
                    Toast.LENGTH_SHORT
                ).show()
                viewBinding.progressBar.visibility = View.GONE
            }
        }
    }

    private fun showDialogChooseBirthday() {
        val date =
            OnDateSetListener { view, year, month, day ->
                myCalendar.set(Calendar.YEAR, year)
                myCalendar.set(Calendar.MONTH, month)
                myCalendar.set(Calendar.DAY_OF_MONTH, day)
                updateLabel()
            }
        viewBinding.edtBirthday.setOnClickListener {
            DatePickerDialog(
                requireContext(),
                date,
                myCalendar.get(Calendar.YEAR),
                myCalendar.get(Calendar.MONTH),
                myCalendar.get(Calendar.DAY_OF_MONTH)
            ).show()
        }
    }

    private fun showDialogChooseGender() {
        Log.d(TAG, "showDialogChooseGender: ")
        viewBinding.edtGender.setOnClickListener {
            val listGender = resources.getStringArray(Const.GENDER_ARRAYS)
            val mBuilder: AlertDialog.Builder = AlertDialog.Builder(requireContext())
            mBuilder.setTitle(getString(Const.TITLE_CHOOSE_GENDER))

            mBuilder.setSingleChoiceItems(
                listGender, -1
            ) { dialog, i ->
                Log.d(TAG, "showDialogChooseGender: index = $i and gender = ${listGender.get(i)}")
                viewBinding.edtGender.setText(listGender[i])
                dialog.dismiss()
            }
            mBuilder.create().show()
        }
    }

    private fun updateLabel() {
        val myFormat = "MM/dd/yy"
        val dateFormat = SimpleDateFormat(myFormat, Locale.US)
        viewBinding.edtBirthday.setText(dateFormat.format(myCalendar.time))
    }

    private fun initViewChooseTechnical() {
        Log.d(TAG, "initViewChooseTechnical: ")
        val adapterTechnique = ArrayAdapter.createFromResource(
            requireContext(),
            Const.TECHNIQUE_ARRAYS,
            android.R.layout.simple_spinner_item
        )
        viewBinding.technique.adapter = adapterTechnique
        viewBinding.technique.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                Log.d(TAG, "onItemSelected: $p2 and ${TechniqueDoctor.DA_KHOA}")
                when (p2) {
                    TechniqueDoctor.DA_KHOA_KEY -> techniqueDoctor = TechniqueDoctor.DA_KHOA
                    TechniqueDoctor.RANG_HAM_MAT_KEY ->
                        techniqueDoctor =
                            TechniqueDoctor.RANG_HAM_MAT
                    TechniqueDoctor.THAN_KINH_KEY -> techniqueDoctor = TechniqueDoctor.THAN_KINH
                    TechniqueDoctor.XUONG_KHOP_KEY -> techniqueDoctor = TechniqueDoctor.XUONG_KHOP
                }
                viewModel.setTechnicalDoctor(techniqueDoctor)
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {
                Log.d(TAG, "onNothingSelected: ")
            }
        }
    }

    override fun onclickback() {
        addframent(R.id.signupscreen)
    }

    override fun onclickregister() {

        viewBinding.apply {
            Log.d(TAG, "onclickregister: ")

            if (edtNameDoctor.text.toString().isEmpty()) {
                edtNameDoctor.error = getString(Const.INPUT_NAME_ERROR)
                edtNameDoctor.requestFocus()
                return
            }
            if (edtSdtDoctor.text.toString().isEmpty()) {
                edtSdtDoctor.error = getString(Const.INPUT_PHONE_ERROR)
                edtSdtDoctor.requestFocus()
                return
            }
            if (edtEmailDoctor.text.toString().isEmpty()) {
                edtEmailDoctor.error = getString(Const.INPUT_EMAIL_ERROR)
                edtEmailDoctor.requestFocus()
                return
            }
            if (edtSdtDoctor.text.toString().length != 10) {
                edtSdtDoctor.error = getString(Const.INPUT_PHONE_LENGTH_ERROR)
                edtSdtDoctor.requestFocus()
                return
            }
            if (edtLocationDoctor.text.toString().isEmpty() && edtLocationDoctor.isVisible) {
                edtLocationDoctor.error = getString(Const.INPUT_ADDRESS_ERROR)
                edtLocationDoctor.requestFocus()
                Log.d(TAG, "edtLocationDoctor: text is null")
                return
            }
            if (edtBirthday.text.toString().isEmpty()) {
                edtBirthday.error = getString(Const.INPUT_BIRTHDAY_ERROR)
                edtBirthday.requestFocus()
                return
            }
            if (edtGender.text.toString().isEmpty()) {
                edtGender.error = getString(Const.INPUT_GENDER_ERROR)
                edtGender.requestFocus()
                return
            }
            if (edtPassDoctor.text.toString().isEmpty()) {
                edtPassDoctor.error = getString(Const.INPUT_PASSWORD_ERROR)
                edtPassDoctor.requestFocus()
                return
            }

            if (edtPassDoctor.text.toString().length <= 7) {
                edtPassDoctor.error = getString(Const.INPUT_PASSWORD_LENGTH_ERROR)
                edtPassDoctor.requestFocus()
                return
            }
            if (edtRePasswordDoctor.text.toString().isEmpty()) {
                edtRePasswordDoctor.error = getString(Const.INPUT_RE_PASSWORD_ERROR)
                edtRePasswordDoctor.requestFocus()
                return
            }
            if (edtPassDoctor.text.toString() != edtRePasswordDoctor.text.toString()) {
                edtRePasswordDoctor.error = getString(Const.INPUT_RE_PASSWORD_NOT_VALID)
                edtRePasswordDoctor.requestFocus()
                return
            }
            if (!cbDoctor.isChecked) {
                cbDoctor.error = getString(Const.NOT_CHECK_POLICY)
                return
            }
            if (techniqueDoctor.isNullOrEmpty() && technique.isVisible) {
                Toast.makeText(
                    requireContext(),
                    Const.TOAST_NOT_CHOOSE_TECHNICAL,
                    Toast.LENGTH_SHORT
                ).show()
                return
            }
            Log.d(TAG, "onclickregister: call save data ")
            viewBinding.progressBar.visibility = View.VISIBLE
            this@SignupDoctorFragment.viewModel.insertUser(techniqueDoctor)
        }
    }

    override fun onclicklogin() {
        addframent(R.id.login)
    }

    override fun clickDrawbleEndPass() {
        viewBinding.edtPassDoctor.apply {
            if (isShowPassword) {
                Log.d(TAG, "clickDrawbleEndPass: 1")
                transformationMethod = null
            } else {
                Log.d(TAG, "clickDrawbleEndPass: 2")
                transformationMethod = PasswordTransformationMethod()
            }
            isShowPassword = !isShowPassword
        }
    }

    override fun clickDrawbleEndRePass() {
        viewBinding.edtRePasswordDoctor.apply {
            if (isShowRePassword) {
                Log.d(TAG, "clickDrawbleEndPass: 1")
                transformationMethod = null
            } else {
                Log.d(TAG, "clickDrawbleEndPass: 2")
                transformationMethod = PasswordTransformationMethod()
            }
            isShowRePassword = !isShowRePassword
        }
    }

    private fun registerUser(username: String, password: String, phone: String) {
        reference =
            FirebaseDatabase.getInstance().getReference("Doctor").child(phone)
        reference?.setValue(
            Doctor(
                phone,
                username,
                "offline",
                jobInsert,
                username,
                "",
                "",
                phone,
                password,
                "",
            )
        )
            ?.addOnCompleteListener(
                OnCompleteListener<Void?> { task ->

                }
            )
    }
}
