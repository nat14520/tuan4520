package com.project.doctorappointment.domain.account

import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.project.doctorappointment.R
import com.project.doctorappointment.base.BaseFragment
import com.project.doctorappointment.databinding.FragmentEditProfileBinding
import com.project.doctorappointment.utils.TypeUser

class EditProfileFragment : BaseFragment<FragmentEditProfileBinding, AccountViewModel>(),
    EditProfileListener {
    override val viewModel by lazy { AccountViewModel(context = requireContext()) }
    override val layoutId: Int = R.layout.fragment_edit_profile
    var userId: Int? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewBinding.apply {
            title = "Chỉnh sửa thông tin cá nhân"
            listen = this@EditProfileFragment
        }
        viewModel.getDataLocal()
        initObserve()
    }

    private fun initObserve() {
        viewModel.isDataUpdate.observe(viewLifecycleOwner) { isSuccess ->
            if (isSuccess) {
                userId?.let{
                    viewModel.getUser(it)
                }
                Toast.makeText(requireContext(), "Cập nhật thành công!", Toast.LENGTH_SHORT).show()
                viewModel.getDataLocal()
            } else {
                Toast.makeText(requireContext(), "Lỗi cập nhật!", Toast.LENGTH_SHORT).show()
            }
        }
        viewModel.userDataLocal.observe(viewLifecycleOwner) {
            userId = it.second.idUser
            viewBinding.userVM = it.second
            if (it.second.job.equals(TypeUser.DOCTOR_VALUE)){
                viewBinding.imgAvatar.setImageResource(R.drawable.doctor)
            }
        }
    }

    override fun saveInfo() {
        viewBinding.apply {
            userId?.let {
                viewModel.updateUserInfo(
                    it,
                    edtName.text.toString().trim(),
                    edtPhone.text.toString().trim(),
                    edtAddress.text.toString().trim(),
                    edtEmail.text.toString().trim()
                )
            } ?: Toast.makeText(requireContext(), "Lỗi cập nhật!", Toast.LENGTH_SHORT).show()

        }
    }

    override fun backPress() {
        backStack()
    }
}