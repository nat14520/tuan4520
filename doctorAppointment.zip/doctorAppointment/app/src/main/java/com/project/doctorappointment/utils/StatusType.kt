package com.project.doctorappointment.utils

enum class StatusType(val value: String) {
    DOI_XAC_NHAN("Đợi xác nhận"),
    DA_XAC_NHAN("Đã xác nhận"),
    DA_TU_CHOI("Đã từ chối")
}