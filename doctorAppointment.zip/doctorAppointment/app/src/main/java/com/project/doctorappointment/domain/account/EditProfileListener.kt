package com.project.doctorappointment.domain.account

interface EditProfileListener {
    fun saveInfo()
    fun backPress()
}