package com.project.doctorappointment.domain.message.chatsmesage

import android.content.Context
import androidx.lifecycle.viewModelScope
import com.project.doctorappointment.base.BaseViewModel
import com.project.doctorappointment.domain.message.modelchat.Chats
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ListChatMessageViewModel(context: Context) : BaseViewModel(context) {
    fun initChat(chats: Chats) {
        viewModelScope.launch(Dispatchers.IO) {
            doctorDao.initChat(chats = chats)
        }
    }
}
