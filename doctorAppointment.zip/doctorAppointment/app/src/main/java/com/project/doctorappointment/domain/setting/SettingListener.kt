package com.project.doctorappointment.domain.setting

interface SettingListener {
    fun goToChangePass()
    fun goToEditProfile()
    fun logOut()
    fun backPress()
}