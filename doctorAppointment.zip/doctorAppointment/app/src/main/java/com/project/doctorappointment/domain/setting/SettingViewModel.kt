package com.project.doctorappointment.domain.setting

import android.content.Context
import android.util.Log
import androidx.lifecycle.viewModelScope
import com.project.doctorappointment.base.BaseViewModel
import kotlinx.coroutines.async
import kotlinx.coroutines.launch

class SettingViewModel(context: Context) : BaseViewModel(context) {
    fun logOut() {
        Log.d(TAG, "logOut: ")
        viewModelScope.launch {
            async { userDataStore.logOutStoreUser() }
            async { doctorDao.deleteAll() }
        }
    }
}
