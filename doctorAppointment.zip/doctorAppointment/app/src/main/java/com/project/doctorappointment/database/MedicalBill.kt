package com.project.doctorappointment.database

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "medical_bills")
data class MedicalBill(
    @PrimaryKey(autoGenerate = true) val id_docter: Int?,
    @ColumnInfo(name = "id_patient") val id_patient: Int?,
    @ColumnInfo(name = "status") val status: Boolean = false,
    @ColumnInfo(name = "day_medical") val day_medical: String?,
    @ColumnInfo(name = "phone") val phone: String? = null,
    @ColumnInfo(name = "pass") val pass: String? = null,
    @ColumnInfo(name = "time_medical") val time_medical: String?,
    @ColumnInfo(name = "disease_description") val disease_description: String?,
    @ColumnInfo(name = "form") val form: String?,
    @ColumnInfo(name = "form_pay") val form_pay: String?,
)
