package com.project.doctorappointment.domain.schedule

import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.project.doctorappointment.base.BaseViewModel
import com.project.doctorappointment.database.BookDoctor
import com.project.doctorappointment.utils.StatusType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class ScheduleViewModel(context: Context) : BaseViewModel(context) {
    val mListBook = MutableLiveData<List<BookDoctor>>()
    val mIsSuccess = MutableLiveData<Boolean>()

    private val _namePatient = MutableLiveData<String>("")
    val namePatient: LiveData<String> = _namePatient

    fun getListBookWithUser(userId: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            doctorDao.getListBookWithUser(userId).collect {
                mListBook.postValue(it)
            }
        }
    }

    fun getListBookWithDoctor(idDoctor: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            doctorDao.getListBookWithDoctor(idDoctor).collect {
                mListBook.postValue(it)
            }
        }
    }

    fun updateStatus(idBook: Int, status: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val isSuccess = doctorDao.updateStatusBook(idBook, status)
            if (isSuccess >= 0) {
                mIsSuccess.postValue(true)
            } else mIsSuccess.postValue(false)
        }
    }

    fun deleteBook(bookDoctor: BookDoctor) {
        viewModelScope.launch(Dispatchers.IO) {
            doctorDao.deleteBook(bookDoctor)
        }
    }

    fun updateBook(
        idBook: Int, date: String, time: String,
        description: String, examinationForm: String,
        payment: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val status = StatusType.DOI_XAC_NHAN.value
            val isSuccess = doctorDao.updateBook(
                idBook, date, time,
                description, examinationForm,
                payment, status
            )
            if (isSuccess >= 0) {
                mIsSuccess.postValue(true)
            } else mIsSuccess.postValue(false)
        }
    }

    fun getNamePatient(idUser: Int) {
        Log.d(TAG, "getNamePatient: $idUser")
        viewModelScope.launch(Dispatchers.IO) {
            doctorDao.getUser(idUser).collectLatest {
                Log.d(TAG, "getNamePatient: collect latest with value $it")
                it.name?.let {
                    _namePatient.postValue(it)
                }
            }
        }
    }
}