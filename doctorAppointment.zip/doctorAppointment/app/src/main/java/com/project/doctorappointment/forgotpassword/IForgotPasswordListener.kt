package com.project.doctorappointment.forgotpassword

interface IForgotPasswordListener {
    fun cancelUpdatePassword()
    fun confirmPassword()
    fun moveToRegisterScreen()
}