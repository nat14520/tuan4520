package com.project.doctorappointment.domain.schedule

interface ScheuleListener {
    fun onBackButton()
    fun onClickRightButton()
    fun onClickLeftButton()
}