package com.project.doctorappointment.domain.search_doctor

import android.content.Context
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.project.doctorappointment.base.BaseViewModel
import com.project.doctorappointment.database.Doctor
import com.project.doctorappointment.utils.TypeUser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class SearchDoctorViewModel(context: Context) : BaseViewModel(context) {

    private var listUserDoctor = mutableListOf<Doctor>()

    private val _listResultDoctorLiveData = MutableLiveData<List<Doctor>>()
    val listResultDoctorLiveData: LiveData<List<Doctor>> = _listResultDoctorLiveData

    private val listResult = mutableListOf<Doctor>()

    init {
        Log.d(TAG, "init viewmodel: ")
        getListUser()
    }

    fun searchDoctor(text: String) {
        Log.d(TAG, "searchDoctor: $text")
        if (text.isNotEmpty()) {
            viewModelScope.launch(Dispatchers.IO) {
                doctorDao.searchListDoctor(text).collectLatest {
                    Log.d(TAG, "searchDoctor: result = $it")
                    listResult.clear()
                    listResult.addAll(it)
                    _listResultDoctorLiveData.postValue(listResult)
                }
            }
        } else {
            listResult.clear()
            _listResultDoctorLiveData.postValue(listResult)
        }
    }

    fun deleteAllResult() {
        Log.d(TAG, "deleteAllResult: ")
        listResult.clear()
        _listResultDoctorLiveData.postValue(listResult)
    }

    private fun getListUser() {
        viewModelScope.launch(Dispatchers.IO) {
            doctorDao.getListUserJob(TypeUser.DOCTOR_VALUE).collectLatest {
                Log.d(TAG, "getListUser: $it")
                listUserDoctor.addAll(it)
            }
        }
    }
}