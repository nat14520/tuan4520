package com.project.doctorappointment.domain.message

import android.os.Bundle
import android.util.Log
import android.view.View
import com.google.firebase.database.*
import com.project.doctorappointment.R
import com.project.doctorappointment.base.BaseFragment
import com.project.doctorappointment.database.Doctor
import com.project.doctorappointment.databinding.FragmentListMessageBinding
import com.project.doctorappointment.domain.message.modelchat.Chats
import com.project.doctorappointment.domain.message.modelchat.Chatslist

class ListMessagerFragment :
    BaseFragment<FragmentListMessageBinding, ListMessageViewModel>(),
    UserAdapter.McallBack {

    private var userlist = mutableListOf<Chatslist>()
    private var mAdapter: UserAdapter? = null
    private var mUsers: MutableList<Doctor>? = null
    private var idlast: String = ""
    private var user: Doctor? = null
    override val viewModel by lazy { ListMessageViewModel(context = requireContext()) }
    override val layoutId: Int = R.layout.fragment_list_message
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel.getDataLocal()
        viewModel.userDataLocal.observe(viewLifecycleOwner) {
            user = it.second
            inintView()
        }
    }

    private fun ChatsListings() {
        viewBinding.apply {
            mUsers = mutableListOf()
            val databaseReference: DatabaseReference =
                FirebaseDatabase.getInstance().getReference("Doctor")
            databaseReference.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    mUsers.let { it?.clear() }
                    var users: Doctor
                    for (ds in snapshot.children) {
                        users = ds.getValue(Doctor::class.java)!!
                        if (!users.phone.equals(user?.phone)) {
                            if (users.phone.equals(idlast)) {
                                mUsers.let { it?.add(0, users) }
                            } else {
                                mUsers.let { it?.add(users) }
                            }
                        }
                    }
                    mAdapter =
                        UserAdapter(
                            user?.phone.toString(),
                            context,
                            mUsers!!,
                            isChat = true,
                            this@ListMessagerFragment
                        )
                    viewBinding.chatRecyclerviewChatfrag.adapter = mAdapter
                    mAdapter.let { it?.notifyDataSetChanged() }
                }

                override fun onCancelled(error: DatabaseError) {}
            })
        }
    }

    override fun onClick(doctor: Doctor) {

        val bundle = Bundle()
        bundle.putString("namedoctor", doctor.name.toString())
        bundle.putString("friendid", doctor.phone.toString())
        bundle.putString("userid", user?.phone.toString())
        addframent(R.id.chatMessageFragment, bundle)
    }

    private fun getIndexlast() {
        viewBinding.apply {
            val reference = FirebaseDatabase.getInstance().getReference("Chats")
            reference.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    for (ds in snapshot.children) {
                        val chats = ds.getValue(Chats::class.java)
                        if (chats?.sender.equals(user?.phone.toString())) {
                            idlast = chats?.reciever.toString()
                        } else if (chats?.reciever.equals(user?.phone.toString())) {
                            idlast = chats?.sender.toString()
                        }
                    }
                }

                override fun onCancelled(error: DatabaseError) {}
            })
        }
    }

    private fun inintView() {
        getIndexlast()
        ChatsListings()
        viewBinding.apply {
            viewBinding.showMessage.text = user?.name
            val reference = FirebaseDatabase.getInstance().getReference("Chatslist")
                .child(user?.phone.toString())
            reference.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                   userlist.clear()
                    for (ds in snapshot.children) {
                        Log.d(TAG, "onDataChangeget value: " + snapshot.children.toString())
                        val chatslist1 = ds.getValue(Chatslist::class.java)
                        if (chatslist1 != null) {
                            userlist.add(chatslist1)
                        }
                    }
                    ChatsListings()
                }

                override fun onCancelled(error: DatabaseError) {}
            })
        }
    }

    private fun ListUser(friendid: String, uid: String): MutableList<String> {
        var lstString = mutableListOf<String>()
        val reference = FirebaseDatabase.getInstance().getReference("Chats")
        reference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                for (ds in snapshot.children) {
                    val chats: Chats? = ds.getValue(Chats::class.java)
                    if (uid != "" && chats != null) {
                        if (chats.sender.equals(uid) && chats.reciever.equals(friendid)
                        ) {
                            lstString.add(friendid)
                        }
                    }
                    Log.d(TAG, "onDataChange: " + lstString.size)
                }
            }

            override fun onCancelled(error: DatabaseError) {}
        })
        return lstString
    }
}
