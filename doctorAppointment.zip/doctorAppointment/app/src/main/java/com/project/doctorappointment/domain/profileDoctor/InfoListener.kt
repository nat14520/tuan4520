package com.project.doctorappointment.domain.profileDoctor

import android.view.View

interface InfoListener {
    fun backStackHome()
    fun onClickBookDoctor()
    fun onClickSelectDate()
    fun onClickSelectTime()
    fun onClickRate()
    fun onClickMessage()
}