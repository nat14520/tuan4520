package com.project.doctorappointment.domain.chatbot

import android.content.Context
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.project.doctorappointment.base.BaseViewModel
import com.project.doctorappointment.database.ChatBot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class ChatBotViewModel(context: Context):BaseViewModel(context) {
    fun sendMessager(chatBot: ChatBot) {
        viewModelScope.launch(Dispatchers.IO) {
            doctorDao.sendMessager(chatBot).apply {
                delay(200)
                getListChat()
            }
        }
    }

    val liveDataChat = MutableLiveData<List<ChatBot>>()
    fun getListChat() {
        viewModelScope.launch(Dispatchers.IO) {
            doctorDao.getListChatBot().collect {
                liveDataChat.postValue(it)
            }
        }
    }
}