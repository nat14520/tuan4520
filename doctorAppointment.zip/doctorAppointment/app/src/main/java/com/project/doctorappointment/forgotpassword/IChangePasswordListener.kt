package com.project.doctorappointment.forgotpassword

interface IChangePasswordListener {

    fun onBackScreen()
    fun onConfirmChangePassword()
    fun clickDrawbleEndNewPass()
    fun clickDrawbleEndOldPass()
    fun clickDrawbleEndEnterPass()
}