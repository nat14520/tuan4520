package com.project.doctorappointment.domain.profileDoctor

import android.app.Dialog
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.RatingBar
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatButton
import androidx.fragment.app.DialogFragment
import com.project.doctorappointment.R
import com.project.doctorappointment.database.Doctor

class DialogRateDoctor(val mCallBack: ((String) -> Unit)) : DialogFragment() {
    val viewModel by lazy { InFoViewModel(context = requireContext()) }
    private var btnConfirm: View? = null
    private var btnCancel: View? = null
    private var edtComment: View? = null
    private var rtbStar: View? = null
    private var mDoctor: Doctor? = null
    private var mRatePoint: String? = null
    private var mComment: String? = null

    companion object {
        fun newInstance(doctor: Doctor?, callBack: (String) -> Unit): DialogRateDoctor {
            val args = Bundle()
            args.putSerializable("doctor_data", doctor)
            val fragment = DialogRateDoctor(callBack)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return activity?.let {
            mDoctor = arguments?.getSerializable("doctor_data") as? Doctor
            val inflater = requireActivity().layoutInflater
            val builder = AlertDialog.Builder(it)
            val view = inflater.inflate(R.layout.dialog_rate_doctor, null)
            builder.setView(view)
            btnConfirm = view.findViewById<AppCompatButton>(R.id.btnConfirm)
            btnCancel = view.findViewById<AppCompatButton>(R.id.btnCancel)
            edtComment = view.findViewById<EditText>(R.id.edtComment)
            rtbStar = view.findViewById<RatingBar>(R.id.rtbStar)
            initListener()
            builder.create()
        } ?: throw IllegalStateException("Activity cannot be null")
    }

    private fun initListener() {
        btnCancel?.setOnClickListener {
            Log.d("TAG", "onCreateDialog: click button no")
            this.dismiss()
        }
        btnConfirm?.setOnClickListener {
            Log.d("TAG", "onCreateDialog:click button yes ")
            mComment = (edtComment as? EditText)?.text.toString()
            mRatePoint = (rtbStar as RatingBar).rating.toString()
            mDoctor?.let { doctor ->
                viewModel.updateRate(doctor.idUser, mRatePoint ?: "", mComment ?: "")
            }

            mCallBack.invoke(mRatePoint ?: "0")
            this.dismiss()
        }
    }
}