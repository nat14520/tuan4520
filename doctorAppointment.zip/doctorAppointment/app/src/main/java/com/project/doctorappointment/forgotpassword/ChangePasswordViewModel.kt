package com.project.doctorappointment.forgotpassword

import android.content.Context
import android.util.Log
import androidx.lifecycle.*
import androidx.lifecycle.viewmodel.CreationExtras
import com.project.doctorappointment.base.BaseViewModel
import com.project.doctorappointment.database.Doctor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ChangePasswordViewModel(context: Context) : BaseViewModel(context) {

    var oldPassword = ""
    var newPassword = ""
    var reNewPassword = ""

    var userData = Doctor()

    private val _isChangePasswordSuccess = MutableLiveData(false)
    val isChangePasswordSuccess: LiveData<Boolean> = _isChangePasswordSuccess

    private val _isDismisDialog = MutableLiveData(false)
    val isDismisDialog: LiveData<Boolean> = _isDismisDialog

    private val _isShowLoading = MutableLiveData(false)
    val isShowLoading: LiveData<Boolean> = _isShowLoading

    init {
        viewModelScope.launch(Dispatchers.IO) {
            userDataStore.userDataSaved.collect {
                Log.d(TAG, "userDataSaved: data = $it ")
                userData = it
            }
        }
    }

    fun confirmPassword() {
        Log.d(TAG, "confirmPassword: ")
        _isShowLoading.postValue(true)
        viewModelScope.launch(Dispatchers.IO) {
            Log.d(TAG, "confirmPassword: called")
            userData.pass = newPassword
            val result = doctorDao.updatePassword(userData)
            Log.d(TAG, "confirmPassword: result = $result")
            if (result >= 0) {
                Log.d(TAG, "confirmPassword: result = true")
                _isChangePasswordSuccess.postValue(true)
                _isShowLoading.postValue(false)
            } else {
                _isShowLoading.postValue(false)
                _isChangePasswordSuccess.postValue(false)
            }
        }
    }

    fun saveDataStore() {
        Log.d(TAG, "saveDataStore: ")
        viewModelScope.launch(Dispatchers.IO) {
            userDataStore.storeUser(userData)
        }
    }

    fun dismissDialog() {
        Log.d(TAG, "dismissDialog: ")
        _isDismisDialog.value?.let {
            _isDismisDialog.postValue(true)
        }
    }

    companion object {
        fun provideFactory(context: Context): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                override fun <T : ViewModel> create(
                    modelClass: Class<T>,
                    extras: CreationExtras
                ): T {
                    return ChangePasswordViewModel(context) as T
                }
            }
    }
}