package com.project.doctorappointment.base

import android.view.View
import androidx.core.view.isVisible
import androidx.databinding.BindingAdapter

object AppBinding {
    @JvmStatic
    @BindingAdapter("isVisible")
    fun setVisible(view: View, isVisible: Boolean) {
        view.isVisible = isVisible
    }
}