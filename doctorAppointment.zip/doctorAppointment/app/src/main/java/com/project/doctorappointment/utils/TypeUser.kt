package com.project.doctorappointment.utils

object TypeUser {
    const val DOCTOR_VALUE = "Doctor"
    const val PATIENT_VALUE = "Patient"
    const val TYPE_DOCTOR = 1
    const val TYPE_PATIENT = 2
}