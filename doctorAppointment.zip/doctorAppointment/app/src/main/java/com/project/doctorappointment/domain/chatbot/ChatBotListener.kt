package com.project.doctorappointment.domain.chatbot

interface ChatBotListener {
    fun backStackHome()
    fun sendMessage()
}