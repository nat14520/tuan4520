package com.project.doctorappointment.domain.login

import android.content.Context
import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.project.doctorappointment.base.BaseViewModel
import com.project.doctorappointment.database.Doctor
import kotlinx.coroutines.launch

class LoginViewModel(application: Context) : BaseViewModel(application = application) {

    /*  fun insertDataDoctor(doctor: Doctor) = viewModelScope.launch(Dispatchers.IO) {
          doctorDao.insertUser(doctor = doctor)
      }

      fun insertData(medicalBill: MedicalBill) = viewModelScope.launch(Dispatchers.IO) {
          doctorDao.insertMedical(medicalBill = medicalBill)
      }

      val data = MutableLiveData<List<Doctor>>()
      fun getListUserDoctor(){
          viewModelScope.launch(Dispatchers.IO){
              doctorDao.getListUser().collect{
                  data.postValue(it)
              }
          }
      }

      val data1 = MutableLiveData<List<MedicalBill>>()
      fun getListUser(){
          viewModelScope.launch(Dispatchers.IO){
              doctorDao.getListUser().collect{
                  data.postValue(it)
              }
          }
      }*/
    val userData = Doctor()

    private val _isLoginSuccess = MutableLiveData<Int>()
    val isLoginSuccess = _isLoginSuccess

    private var isRememberUser = false

    fun loginSuccess() {
        Log.d(TAG, "loginSuccess: called ")
        val checkPhone = doctorDao.checkAccountWithPhoneNumber(userData.phone)
        if (checkPhone != null) {
            val checkAccount = doctorDao.getUser(userData.phone, userData.pass)
            Log.d(TAG, "loginSuccess: checkacount$checkAccount")
            if (checkAccount != null) {
                isLoginSuccess.postValue(LOGIN_SUCCESS)
                viewModelScope.launch {
                    userDataStore.storeUser(checkAccount)
                    Log.d(TAG, "loginSuccess: save data user with isRemember = $isRememberUser")
                    if (isRememberUser) userDataStore.rememberAccount(true)
                }
            } else isLoginSuccess.postValue(LOGIN_FAILED)
        } else _isLoginSuccess.postValue(NOT_YET_REGISTER)
    }

    fun setIsRememberUser(isRemember: Boolean) {
        Log.d(TAG, "setIsRememberUser: called with isRemember = $isRemember")
        isRememberUser = isRemember
    }

    fun setPhone(phone: String) {
        Log.d(TAG, "setUserName: $phone")
        userData.phone = phone
    }

    fun setPassword(pass: String) {
        Log.d(TAG, "setPassword: $pass")
        userData.pass = pass
    }

    companion object {
        const val LOGIN_SUCCESS = 1
        const val LOGIN_FAILED = 2
        const val NOT_YET_REGISTER = 3
    }
}