package com.project.doctorappointment.domain.home

interface HomeListener {
    fun onclickChatBot()
    fun onClickSearchDoctor()
}