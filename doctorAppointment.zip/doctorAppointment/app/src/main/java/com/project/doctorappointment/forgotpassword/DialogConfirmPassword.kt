package com.project.doctorappointment.forgotpassword

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatButton
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.activityViewModels
import com.project.doctorappointment.R

class DialogConfirmPassword : DialogFragment() {

    private val viewModel: ChangePasswordViewModel by activityViewModels {
        ChangePasswordViewModel.provideFactory(requireContext())
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        return activity?.let {
            val inflater = requireActivity().layoutInflater
            val builder = AlertDialog.Builder(it)
            val view = inflater.inflate(R.layout.dialog_confirm_change_password, null)
            builder.setView(view)
            val btnNo = view.findViewById<AppCompatButton>(R.id.btnNo)
            val btnYes = view.findViewById<AppCompatButton>(R.id.btnYes)
            btnNo.setOnClickListener {
                Log.d("TAG", "onCreateDialog: click button no")
                viewModel.dismissDialog()
            }
            btnYes.setOnClickListener {
                Log.d("TAG", "onCreateDialog:click button yes ")
                viewModel.confirmPassword()
            }
            builder.create()
        } ?: throw IllegalStateException("Activity cannot be null")
    }
}