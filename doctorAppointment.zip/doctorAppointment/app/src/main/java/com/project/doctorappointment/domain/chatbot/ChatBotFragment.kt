package com.project.doctorappointment.domain.chatbot

import android.os.Bundle
import android.util.Log
import android.view.View
import com.project.doctorappointment.R
import com.project.doctorappointment.base.BaseFragment
import com.project.doctorappointment.database.ChatBot
import com.project.doctorappointment.databinding.FragmentChatBotBinding

class ChatBotFragment:BaseFragment<FragmentChatBotBinding,ChatBotViewModel>(),ChatBotListener {
    override val viewModel by lazy { ChatBotViewModel(context = requireContext()) }
    override val layoutId: Int = R.layout.fragment_chat_bot
    private val adapterChat by lazy {
        ChatBotAdapter(arrayListOf())
    }
    private val list = arrayListOf<ChatBot>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewModel.getListChat()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewBinding.apply {
            adapter = adapterChat
            listen = this@ChatBotFragment
            viewModel.apply {
                liveDataChat.observe(viewLifecycleOwner) {
                    Log.d("TAG", "onViewCreated: $it")
                    if (!it.isNullOrEmpty()) {
                        adapterChat.setData(it as ArrayList<ChatBot> /* = java.util.ArrayList<com.project.doctorappointment.database.ChatBot> */)
                        list.addAll(it)
                    }
                }
            }
        }
    }

    override fun backStackHome() {
        backStack()
    }

    override fun sendMessage() {
        viewBinding.apply {
            viewModel.sendMessager(chatBot = ChatBot("user", edtChat.text.toString().trim()))
            when (adapterChat.itemCount) {
                0 -> {}
                1 -> {
                    viewModel.sendMessager(
                        ChatBot(
                            "bot", "Xin chào cảm ơn bạn đã liên hệ với chúng tôi\n" +
                                    "hãy mô tả tình trạng sức khỏe của bạn."
                        )
                    )
                }
                2 -> {

                }
                3 -> {
                    viewModel.sendMessager(
                        ChatBot(
                            "bot", "chúng tôi đã ghi nhận tình trạng sức khỏe của\n" +
                                    "bạn, hãy để lại SĐT của bạn để bác sĩ liên hệ tư\n" +
                                    "vấn cho bạn trong vòng 1 giờ nhé."
                        )
                    )
                }
                4 -> {

                }
                else -> {}
            }
            edtChat.setText("")
        }
    }
}