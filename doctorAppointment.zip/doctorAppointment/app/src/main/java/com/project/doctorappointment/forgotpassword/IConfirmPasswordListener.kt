package com.project.doctorappointment.forgotpassword

interface IConfirmPasswordListener {
    fun cancelUpdatePassword()
    fun confirmPassword()
    fun moveToRegisterScreen()
}