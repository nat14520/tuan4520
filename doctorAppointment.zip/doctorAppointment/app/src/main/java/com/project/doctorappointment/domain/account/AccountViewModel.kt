package com.project.doctorappointment.domain.account

import android.content.Context
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.project.doctorappointment.base.BaseViewModel
import com.project.doctorappointment.database.Doctor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AccountViewModel(context: Context) : BaseViewModel(context) {
    val userData = MutableLiveData<Doctor>()
    val jobData = MutableLiveData<String>()
    val isDataUpdate = MutableLiveData<Boolean>()

    fun getUser(userId: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            doctorDao.getUser(userId).collect {
                userData.postValue(it)
                userDataStore.storeUser(it)
            }
        }
    }

    fun getJobUser() {
        viewModelScope.launch(Dispatchers.IO) {
            doctorDao.getJobUser("id").collect {
                jobData.postValue(it)
            }
        }
    }

    fun updateUserInfo(userId: Int, name: String, phone: String, address: String,email:String) {
        viewModelScope.launch(Dispatchers.IO) {
            val result = doctorDao.updateUserInfo(userId, name, phone, address, email)
            if (result >= 0) isDataUpdate.postValue(true) else isDataUpdate.postValue(false)
        }
    }
}