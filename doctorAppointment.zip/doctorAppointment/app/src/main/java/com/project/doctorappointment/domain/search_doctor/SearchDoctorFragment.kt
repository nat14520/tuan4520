package com.project.doctorappointment.domain.search_doctor

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import androidx.core.os.bundleOf
import com.project.doctorappointment.R
import com.project.doctorappointment.base.BaseFragment
import com.project.doctorappointment.databinding.FragmentSearchDoctorBinding
import com.project.doctorappointment.domain.search_doctor.adapter.SearchDoctorAdapter

class SearchDoctorFragment : BaseFragment<FragmentSearchDoctorBinding, SearchDoctorViewModel>(),
    ISearchDoctorListener {
    override val viewModel: SearchDoctorViewModel by lazy { SearchDoctorViewModel(requireContext()) }
    override val layoutId: Int = R.layout.fragment_search_doctor

    private val doctorAdapter: SearchDoctorAdapter = SearchDoctorAdapter()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewBinding.apply {
            viewModel = this@SearchDoctorFragment.viewModel
            onListener = this@SearchDoctorFragment
            recyclerViewDoctor.adapter = doctorAdapter
        }
        doctorAdapter.setOnClickListener { doctor, view ->
            Log.d(TAG, "onViewCreated: with doctor = $doctor, view = $view")
            addframent(R.id.infoDoctor, bundleOf("doctor" to doctor))
        }
        searchDoctorWithTechniqueAndName()
        observeResultSearchDoctor()
    }

    override fun onBackScreen() {
        Log.d(TAG, "onBackScreen: ")
        backStack()
    }

    override fun onDeleteAll() {
        Log.d(TAG, "onDeleteAll: ")
        viewBinding.searchDoctor.setText("")
        viewModel.deleteAllResult()
    }

    private fun searchDoctorWithTechniqueAndName() {
        viewBinding.searchDoctor.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                Log.d(TAG, "beforeTextChanged: $p0")
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                Log.d(TAG, "onTextChanged: $p0")
                viewModel.searchDoctor(p0.toString())

            }

            override fun afterTextChanged(p0: Editable?) {
                Log.d(TAG, "afterTextChanged: ")
            }

        })
    }

    private fun observeResultSearchDoctor() {
        Log.d(TAG, "observeResultSearchDoctor: ")
        viewModel.listResultDoctorLiveData.observe(viewLifecycleOwner) {
            Log.d(TAG, "observeResultSearchDoctor: $it")
            doctorAdapter.setData(it)
        }
    }
}