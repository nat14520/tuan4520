package com.project.doctorappointment.domain.login

interface LoginListener {
    fun onclickback()
    fun onclicklogin()
    fun onclickregister()
    fun onClickForgotPassword()
    fun clickDrawbleEndPass()
}