package com.project.doctorappointment.domain.message.chatsmesage

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View

import com.bumptech.glide.Glide
import com.google.firebase.database.*
import com.project.doctorappointment.R
import com.project.doctorappointment.base.BaseFragment
import com.project.doctorappointment.database.Doctor
import com.project.doctorappointment.databinding.FragmentChatMessageBinding
import com.project.doctorappointment.domain.message.MessageAdapter
import com.project.doctorappointment.domain.message.modelchat.Chats

class ChatMessageFragment : BaseFragment<FragmentChatMessageBinding, ListChatMessageViewModel>() {
    override val viewModel by lazy { ListChatMessageViewModel(context = requireContext()) }
    override val layoutId: Int = R.layout.fragment_chat_message
    private var user: Doctor ? = null
    private var reference: DatabaseReference? = null
    private val myid by lazy { arguments?.getString("userid") }
    private val friendid by lazy { arguments?.getString("friendid") }
    private val namedoctor by lazy { arguments?.getString("namedoctor") }
    private var message = ""
    private var chatsList: ArrayList<Chats>? = null
    var messageAdapter: MessageAdapter? = null
    var seenlistener: ValueEventListener? = null
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        Log.d(TAG, "onViewCreated1: " + arguments?.getString("userid") + "my id:" + myid)
        viewBinding.apply {
            usernameOntoolbarMessage.text = namedoctor
            icback.setOnClickListener { view ->
                backStack()
            }
            viewModel.userDataLocal.observe(viewLifecycleOwner) {
                user = it.second
            }
            val reference = FirebaseDatabase.getInstance().getReference("Doctor").child(friendid.toString())
            reference.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val users: Doctor? = snapshot.getValue(Doctor::class.java)
                    usernameOntoolbarMessage.text =
                        users?.name // set the text of the user on textivew in toolbar
                    if (users?.avata_url.equals("")) {
                        profileImageToolbarMessage.setImageResource(R.drawable.user)
                    } else {
                        Glide.with(requireContext()).load(users?.avata_url)
                            .into(profileImageToolbarMessage)
                    }
                    readMessages(myid = myid.toString(), friendid = friendid.toString(),
                        users?.avata_url.toString()
                    )
                }

                override fun onCancelled(error: DatabaseError) {}
            })
            seenMessage(friendid.toString())
            editMessageText.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(
                    s: CharSequence,
                    start: Int,
                    count: Int,
                    after: Int
                ) {
                    if (s.toString().trim().length > 0) {
                        sendMesssageBtn.setEnabled(true)
                    } else {
                        sendMesssageBtn.setEnabled(false)
                    }
                }

                override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                    val text: String = editMessageText.getText().toString()
                    if (!text.startsWith(" ")) {
                        editMessageText.getText().insert(0, " ")
                    }
                }

                override fun afterTextChanged(s: Editable) {}
            })
            sendMesssageBtn.setOnClickListener { view ->
                message = editMessageText.text.toString()
                sendMessage(myid.toString(), friendid.toString(), message)
                editMessageText.setText("")
            }
        }
    }

    private fun seenMessage(friendid: String) {
        reference = FirebaseDatabase.getInstance().getReference("Chats")
        seenlistener = reference!!.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                for (ds in snapshot.children) {
                    val chats = ds.getValue(Chats::class.java)
                    if (chats?.reciever?.equals(myid.toString()) == true && chats?.sender.equals(friendid)) {
                        val hashMap = HashMap<String, Any>()
                        hashMap["isseen"] = true
                        ds.ref.updateChildren(hashMap)
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {}
        })
    }

    private fun readMessages(myid: String, friendid: String, imageURL: String) {
        chatsList = ArrayList()
        val reference = FirebaseDatabase.getInstance().getReference("Chats")
        reference.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                chatsList!!.clear()
                for (ds in snapshot.children) {
                    val chats = ds.getValue(Chats::class.java)
                    if (chats?.sender.equals(myid) && chats?.reciever.equals(friendid) ||
                        chats?.sender.equals(friendid) && chats?.reciever.equals(myid)
                    ) {
                        if (chats != null) {
                            chatsList!!.add(chats)
                        }
                    }
                    messageAdapter = MessageAdapter(uid = myid, context, chatsList!!, imageURL)
                    viewBinding.recyclerviewMessages.adapter = messageAdapter
                    viewBinding.recyclerviewMessages.scrollToPosition(chatsList!!.size - 1)
                    messageAdapter.let { it?.notifyDataSetChanged() }
                }
            }

            override fun onCancelled(error: DatabaseError) {}
        })
    }

    private fun sendMessage(myid: String, friendid: String, message: String) {
        val reference = FirebaseDatabase.getInstance().getReference("Chats")
        val hashMap = HashMap<String, Any>()
        hashMap["sender"] = myid
        hashMap["reciever"] = friendid
        hashMap["message"] = message
        hashMap["isseen"] = false
        viewModel.initChat(Chats(sender = myid, reciever = friendid, message = message, isseen = false))
        reference.push().setValue(hashMap)
        val reference1 =
            FirebaseDatabase.getInstance().getReference("Chatslist").child(myid).child(friendid)
        reference1.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (!snapshot.exists()) {
                    reference1.child("id").setValue(friendid)
                }
            }

            override fun onCancelled(error: DatabaseError) {}
        })
    }
}
