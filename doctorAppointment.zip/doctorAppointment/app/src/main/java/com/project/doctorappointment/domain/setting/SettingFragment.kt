package com.project.doctorappointment.domain.setting

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.navigation.fragment.findNavController
import com.project.doctorappointment.R
import com.project.doctorappointment.base.BaseFragment
import com.project.doctorappointment.base.BaseViewModel
import com.project.doctorappointment.databinding.FragmentSettingManageBinding

class SettingFragment : BaseFragment<FragmentSettingManageBinding, SettingViewModel>(),
    SettingListener {
    override val viewModel by lazy { SettingViewModel(requireContext()) }
    override val layoutId: Int = R.layout.fragment_setting_manage
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewBinding.apply {
            title = "Cài đặt"
            listen = this@SettingFragment
        }
    }

    override fun goToChangePass() {
        Log.d(TAG, "goToChangePass: ")
        addframent(R.id.changePasswordFragment)
    }

    override fun goToEditProfile() {
        addframent(R.id.editProfileScreen)
    }

    override fun logOut() {
        findNavController().backQueue.clear()
        addframent(R.id.login)
        Log.d(TAG, "logOut: ")
        viewModel.logOut()
    }

    override fun backPress() {
        backStack()
    }
}